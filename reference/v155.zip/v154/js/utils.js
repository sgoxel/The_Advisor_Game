/* ROAD_PATCH_V2: diagonal connectivity + color fix */
/*
  FILE PURPOSE:
  Small generic helper utilities.

  DEPENDENCIES:
  - none

  PUBLIC API:
  - Game.Utils

  IMPORTANT RULES:
  - Keep this file generic.
  - Do not reference world internals unless absolutely necessary.
*/

window.Game = window.Game || {};

window.Game.Utils = {
  clamp(value, min, max) {
    return Math.max(min, Math.min(max, value));
  },

  percent(part, total) {
    if (total === 0) return 0;
    return Math.round((part / total) * 100);
  },

  lightenHexColor(hex, amount) {
    const value = hex.replace("#", "");
    const num = parseInt(value, 16);

    const r = Math.min(255, (num >> 16) + amount);
    const g = Math.min(255, ((num >> 8) & 255) + amount);
    const b = Math.min(255, (num & 255) + amount);

    return `rgb(${r}, ${g}, ${b})`;
  }
};