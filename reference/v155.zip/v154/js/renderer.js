/* ROAD_PATCH_V2: diagonal connectivity + color fix */

(function(){

  // Bind common globals used throughout this renderer. Other modules
  // typically do `const State = window.Game.State` at their top-level;
  // the renderer is a large IIFE and needs local bindings too.
  window.Game = window.Game || {};
  const Config = window.Game && window.Game.Config;
  const State = window.Game && window.Game.State;
  const RNG = window.Game && window.Game.RNG;

  // Small numeric and transform constants used by the renderer.
  const EPSILON = 1e-6;
  const WORLD_ROTATION_DEGREES = 45;
  const WORLD_SURFACE_Y = 0;
  const GRID_OVERLAY_Y = WORLD_SURFACE_Y + 0.02;
  const MARKER_Y = WORLD_SURFACE_Y + 0.02;

  // Minimal WebGL shader sources required by the renderer's programs.
  const COLOR_VERTEX_SHADER_SOURCE = `attribute vec3 a_position; uniform mat4 u_matrix; void main() { gl_Position = u_matrix * vec4(a_position, 1.0); }`;
  const COLOR_FRAGMENT_SHADER_SOURCE = `precision mediump float; uniform vec4 u_color; void main() { gl_FragColor = u_color; }`;
  const TEXTURE_VERTEX_SHADER_SOURCE = `attribute vec3 a_position; attribute vec2 a_texCoord; uniform mat4 u_matrix; varying vec2 v_texCoord; void main() { v_texCoord = a_texCoord; gl_Position = u_matrix * vec4(a_position, 1.0); }`;
  const TEXTURE_FRAGMENT_SHADER_SOURCE = `precision mediump float; varying vec2 v_texCoord; uniform sampler2D u_texture; void main() { gl_FragColor = texture2D(u_texture, v_texCoord); }`;

  function createShader(gl, type, source) {
    const shader = gl.createShader(type);
    gl.shaderSource(shader, source);
    gl.compileShader(shader);
    if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
      throw new Error(`Shader compile error: ${gl.getShaderInfoLog(shader)}`);
    }
    return shader;
  }

  // Draw inner, sun-facing highlight clipped to the rounded shape interior.
  // This is deliberately separate from the shadow pass and is invoked
  // after the shape texture is painted so the highlight remains visible.
  function drawTerrainShapeInnerLight(ctx, shape, x0, y0, width, height, cornerRadius, cellWidth, cellHeight) {
    try {
      if (!ctx || !shape) return;
      if (shape.light === false) return;

      // Build a rounded-rect path matching the shape
      const path = new Path2D();
      const r = Math.max(0, Math.min(cornerRadius || 0, Math.min(width, height) / 2));
      path.moveTo(x0 + r, y0);
      path.lineTo(x0 + width - r, y0);
      path.arcTo(x0 + width, y0, x0 + width, y0 + r, r);
      path.lineTo(x0 + width, y0 + height - r);
      path.arcTo(x0 + width, y0 + height, x0 + width - r, y0 + height, r);
      path.lineTo(x0 + r, y0 + height);
      path.arcTo(x0, y0 + height, x0, y0 + height - r, r);
      path.lineTo(x0, y0 + r);
      path.arcTo(x0, y0, x0 + r, y0, r);
      path.closePath();

      ctx.save();
      try { ctx.clip(path); } catch (e) { /* some contexts may not support Path2D.clip */ }

      // highlight strength: prefer runtime camera value, fallback to config
      const cfgHL = Number(State.camera && State.camera.highlightStrength != null ? State.camera.highlightStrength : (Config && Config.DEFAULT_HIGHLIGHT_STRENGTH)) || 0.22;
      const hl = Math.max(0, Math.min(2, cfgHL));

      const sunAzRad = degToRad(Number(State.camera.sunAzimuth || 0));
      const sx = Math.cos(sunAzRad);
      const sy = Math.sin(sunAzRad);

      const sunElev = Math.max(0, Math.min(90, Number(State.camera.sunElevation || 45)));
      const sunElevFactor = sunElev / 90;

      const cx = x0 + width * 0.5;
      const cy = y0 + height * 0.5;
      const reach = Math.max(width, height) * 0.6;
      // apply brightness on the opposite side: reverse gradient endpoints
      const gx0 = cx + sx * reach;
      const gy0 = cy + sy * reach;
      const gx1 = cx - sx * reach;
      const gy1 = cy - sy * reach;

      const grad = ctx.createLinearGradient(gx0, gy0, gx1, gy1);
      const alpha = Math.max(0, Math.min(1, hl * (1 - sunElevFactor * 0.6)));
      const stopColor = `rgba(255,236,160,${alpha.toFixed(3)})`;
      grad.addColorStop(0.0, stopColor);
      grad.addColorStop(0.35, `rgba(255,236,160,${(alpha * 0.35).toFixed(3)})`);
      grad.addColorStop(1.0, 'rgba(255,236,160,0)');

      ctx.globalCompositeOperation = 'lighter';
      ctx.fillStyle = grad;
      ctx.fillRect(x0, y0, width, height);
      try { if (console && console.info) console.info(`drawTerrainShapeInnerLight: alpha=${alpha.toFixed(3)} label=${typeof shape.label==='string'?shape.label:'<unnamed>'}`); } catch (e) {}
      ctx.globalCompositeOperation = 'source-over';

    } catch (err) {
      console.warn('drawTerrainShapeInnerLight failed', err);
    } finally {
      ctx.restore();
    }
  }

  // Apply tile-based relief lighting to the interior of a rounded shape.
  // This reuses `computeReliefLight` and `applyReliefLighting` so the
  // same lighting model used for terrain tiles is applied to the
  // shape's texture. Lighting is only applied to the sun-facing tiles
  // clipped to the rounded shape.
  function drawTerrainShapeReliefLighting(ctx, shape, x0, y0, width, height, cornerRadius, cellWidth, cellHeight) {
    try {
      if (!ctx || !shape) return;
      if (shape.light === false) return;

      const world = State.world || {};
      const seed = world.seed || 0;

      // Build rounded rect path in main canvas coordinates for clipping
      const r = Math.max(0, Math.min(cornerRadius || 0, Math.min(width, height) / 2));
      const path = new Path2D();
      path.moveTo(x0 + r, y0);
      path.lineTo(x0 + width - r, y0);
      path.arcTo(x0 + width, y0, x0 + width, y0 + r, r);
      path.lineTo(x0 + width, y0 + height - r);
      path.arcTo(x0 + width, y0 + height, x0 + width - r, y0 + height, r);
      path.lineTo(x0 + r, y0 + height);
      path.arcTo(x0, y0 + height, x0, y0 + height - r, r);
      path.lineTo(x0, y0 + r);
      path.arcTo(x0, y0, x0 + r, y0, r);
      path.closePath();

      // Grab a snapshot of the already-painted texture inside the shape
      const w = Math.max(1, Math.round(width));
      const h = Math.max(1, Math.round(height));
      const tmp = document.createElement('canvas');
      tmp.width = w;
      tmp.height = h;
      const tctx = tmp.getContext('2d');
      // copy the just-drawn area from the main canvas
      try {
        tctx.drawImage(ctx.canvas, x0, y0, width, height, 0, 0, w, h);
      } catch (err) {
        // drawImage can fail in some contexts; abort gracefully
        console.warn('drawTerrainShapeReliefLighting drawImage failed', err);
        return;
      }

      const img = tctx.getImageData(0, 0, w, h);
      const data = img.data;

      const sun = getSunDirection();
      const sunx = sun.x, suny = sun.y;

      // Determine the tile range that intersects the shape bounding box
      const leftTile = Math.floor(x0 / (cellWidth || 1));
      const topTile = Math.floor(y0 / (cellHeight || 1));
      const rightTile = Math.floor((x0 + width - 1) / (cellWidth || 1));
      const bottomTile = Math.floor((y0 + height - 1) / (cellHeight || 1));

      const rows = Math.max(1, (world.rows || 80));
      const cols = Math.max(1, (world.cols || 80));

      // center of shape in local tmp coords
      const cx = w / 2;
      const cy = h / 2;

      for (let tr = topTile; tr <= bottomTile; tr++) {
        for (let tc = leftTile; tc <= rightTile; tc++) {
          if (tr < 0 || tc < 0 || tr >= rows || tc >= cols) continue;

          // pixel range in tmp coordinates
          const tileX0 = Math.max(0, Math.floor(tc * (cellWidth || 1) - x0));
          const tileY0 = Math.max(0, Math.floor(tr * (cellHeight || 1) - y0));
          const tileX1 = Math.max(0, Math.min(w, Math.ceil((tc + 1) * (cellWidth || 1) - x0)));
          const tileY1 = Math.max(0, Math.min(h, Math.ceil((tr + 1) * (cellHeight || 1) - y0)));
          if (tileX1 <= tileX0 || tileY1 <= tileY0) continue;

          // quick sun-facing test: use tile center
          const tileCenterX = (tc + 0.5) * (cellWidth || 1) - x0;
          const tileCenterY = (tr + 0.5) * (cellHeight || 1) - y0;
          const dx = tileCenterX - cx;
          const dy = tileCenterY - cy;
          const dot = dx * sunx + dy * suny;
          if (dot <= 0) continue; // not facing the sun

          // get tile lighting info (same as tiles)
          const lightInfo = computeReliefLight(seed, tr + 0.5, tc + 0.5);
          // skip tiles with no highlight/shadow
          if (!lightInfo || (lightInfo.highlightAmount <= 0 && lightInfo.shadowAmount <= 0)) continue;

          // apply per-pixel lighting within this tile rectangle
          for (let py = tileY0; py < tileY1; py++) {
            for (let px = tileX0; px < tileX1; px++) {
              // ensure pixel is inside the rounded path
              if (!ctx.isPointInPath(path, x0 + px, y0 + py)) continue;
              const idx = (py * w + px) * 4;
              const baseColor = { r: data[idx], g: data[idx + 1], b: data[idx + 2] };
              const lit = applyReliefLighting(baseColor, lightInfo);
              data[idx] = clampByte(lit.r);
              data[idx + 1] = clampByte(lit.g);
              data[idx + 2] = clampByte(lit.b);
            }
          }
        }
      }

      // write back and draw into main canvas clipped to the shape
      tctx.putImageData(img, 0, 0);
      ctx.save();
      ctx.clip(path);
      ctx.drawImage(tmp, x0, y0);
      ctx.restore();

    } catch (err) {
      console.warn('drawTerrainShapeReliefLighting failed', err);
    }
  }

  function createProgram(gl, vs, fs) {
    const program = gl.createProgram();
    gl.attachShader(program, vs);
    gl.attachShader(program, fs);
    gl.linkProgram(program);
    if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {
      throw new Error(`Program link error: ${gl.getProgramInfoLog(program)}`);
    }
    return program;
  }

  function initializeWebGLResources() {
    const gl = State.dom.gl;
    const render = State.render;
    if (render.colorProgram && render.textureProgram) return;

    const colorVs = createShader(gl, gl.VERTEX_SHADER, COLOR_VERTEX_SHADER_SOURCE);
    const colorFs = createShader(gl, gl.FRAGMENT_SHADER, COLOR_FRAGMENT_SHADER_SOURCE);
    render.colorProgram = createProgram(gl, colorVs, colorFs);
    render.positionBuffer = gl.createBuffer();
    render.colorPositionLocation = gl.getAttribLocation(render.colorProgram, "a_position");
    render.colorMatrixLocation = gl.getUniformLocation(render.colorProgram, "u_matrix");
    render.colorLocation = gl.getUniformLocation(render.colorProgram, "u_color");

    const textureVs = createShader(gl, gl.VERTEX_SHADER, TEXTURE_VERTEX_SHADER_SOURCE);
    const textureFs = createShader(gl, gl.FRAGMENT_SHADER, TEXTURE_FRAGMENT_SHADER_SOURCE);
    render.textureProgram = createProgram(gl, textureVs, textureFs);
    render.texturePositionBuffer = gl.createBuffer();
    render.textureCoordBuffer = gl.createBuffer();
    render.texturePositionLocation = gl.getAttribLocation(render.textureProgram, "a_position");
    render.textureCoordLocation = gl.getAttribLocation(render.textureProgram, "a_texCoord");
    render.textureMatrixLocation = gl.getUniformLocation(render.textureProgram, "u_matrix");
    render.textureSamplerLocation = gl.getUniformLocation(render.textureProgram, "u_texture");
    render.backgroundTexture = gl.createTexture();

    gl.bindTexture(gl.TEXTURE_2D, render.backgroundTexture);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);

    gl.enable(gl.BLEND);
    gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);
    gl.enable(gl.DEPTH_TEST);
    gl.depthFunc(gl.LEQUAL);
  }

  function getGridMetrics(scaleWidth) {
    const tileWidth = scaleWidth || State.world.tileWidth;
    const tileHeight = tileWidth;
    return { tileWidth, tileHeight, halfW: tileWidth / 2, halfH: tileHeight / 2, ratio: 1 };
  }

  function degToRad(value) {
    return (value * Math.PI) / 180;
  }

  function clampPitch(value) {
    return Math.max(1, Math.min(89.999, value));
  }

  function vec3Subtract(a, b) {
    return [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
  }

  function vec3Add(a, b) {
    return [a[0] + b[0], a[1] + b[1], a[2] + b[2]];
  }

  function vec3Scale(v, s) {
    return [v[0] * s, v[1] * s, v[2] * s];
  }

  function vec3Dot(a, b) {
    return a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
  }

  function vec3Cross(a, b) {
    return [
      a[1] * b[2] - a[2] * b[1],
      a[2] * b[0] - a[0] * b[2],
      a[0] * b[1] - a[1] * b[0]
    ];
  }

  function vec3Length(v) {
    return Math.hypot(v[0], v[1], v[2]);
  }

  function vec3Normalize(v) {
    const len = vec3Length(v) || 1;
    return [v[0] / len, v[1] / len, v[2] / len];
  }

  function mat4Identity() {
    return new Float32Array([
      1, 0, 0, 0,
      0, 1, 0, 0,
      0, 0, 1, 0,
      0, 0, 0, 1
    ]);
  }

  function mat4Multiply(a, b) {
    const out = new Float32Array(16);
    for (let col = 0; col < 4; col++) {
      for (let row = 0; row < 4; row++) {
        out[col * 4 + row] =
          a[0 * 4 + row] * b[col * 4 + 0] +
          a[1 * 4 + row] * b[col * 4 + 1] +
          a[2 * 4 + row] * b[col * 4 + 2] +
          a[3 * 4 + row] * b[col * 4 + 3];
      }
    }
    return out;
  }

  function mat4Perspective(fovyRad, aspect, near, far) {
    const f = 1.0 / Math.tan(fovyRad / 2);
    const nf = 1 / (near - far);
    return new Float32Array([
      f / aspect, 0, 0, 0,
      0, f, 0, 0,
      0, 0, (far + near) * nf, -1,
      0, 0, (2 * far * near) * nf, 0
    ]);
  }

  function mat4LookAt(eye, target, up) {
    const zAxis = vec3Normalize(vec3Subtract(eye, target));
    const xAxis = vec3Normalize(vec3Cross(up, zAxis));
    const yAxis = vec3Cross(zAxis, xAxis);

    return new Float32Array([
      xAxis[0], yAxis[0], zAxis[0], 0,
      xAxis[1], yAxis[1], zAxis[1], 0,
      xAxis[2], yAxis[2], zAxis[2], 0,
      -vec3Dot(xAxis, eye), -vec3Dot(yAxis, eye), -vec3Dot(zAxis, eye), 1
    ]);
  }

  function mat4Invert(m) {
    const out = new Float32Array(16);
    const b00 = m[0] * m[5] - m[1] * m[4];
    const b01 = m[0] * m[6] - m[2] * m[4];
    const b02 = m[0] * m[7] - m[3] * m[4];
    const b03 = m[1] * m[6] - m[2] * m[5];
    const b04 = m[1] * m[7] - m[3] * m[5];
    const b05 = m[2] * m[7] - m[3] * m[6];
    const b06 = m[8] * m[13] - m[9] * m[12];
    const b07 = m[8] * m[14] - m[10] * m[12];
    const b08 = m[8] * m[15] - m[11] * m[12];
    const b09 = m[9] * m[14] - m[10] * m[13];
    const b10 = m[9] * m[15] - m[11] * m[13];
    const b11 = m[10] * m[15] - m[11] * m[14];

    let det = b00 * b11 - b01 * b10 + b02 * b09 + b03 * b08 - b04 * b07 + b05 * b06;
    if (!det) return null;
    det = 1.0 / det;

    out[0] = (m[5] * b11 - m[6] * b10 + m[7] * b09) * det;
    out[1] = (-m[1] * b11 + m[2] * b10 - m[3] * b09) * det;
    out[2] = (m[13] * b05 - m[14] * b04 + m[15] * b03) * det;
    out[3] = (-m[9] * b05 + m[10] * b04 - m[11] * b03) * det;
    out[4] = (-m[4] * b11 + m[6] * b08 - m[7] * b07) * det;
    out[5] = (m[0] * b11 - m[2] * b08 + m[3] * b07) * det;
    out[6] = (-m[12] * b05 + m[14] * b02 - m[15] * b01) * det;
    out[7] = (m[8] * b05 - m[10] * b02 + m[11] * b01) * det;
    out[8] = (m[4] * b10 - m[5] * b08 + m[7] * b06) * det;
    out[9] = (-m[0] * b10 + m[1] * b08 - m[3] * b06) * det;
    out[10] = (m[12] * b04 - m[13] * b02 + m[15] * b00) * det;
    out[11] = (-m[8] * b04 + m[9] * b02 - m[11] * b00) * det;
    out[12] = (-m[4] * b09 + m[5] * b07 - m[6] * b06) * det;
    out[13] = (m[0] * b09 - m[1] * b07 + m[2] * b06) * det;
    out[14] = (-m[12] * b03 + m[13] * b01 - m[14] * b00) * det;
    out[15] = (m[8] * b03 - m[9] * b01 + m[10] * b00) * det;
    return out;
  }

  function transformPoint(matrix, x, y, z, w) {
    const iw = w === undefined ? 1 : w;
    return [
      matrix[0] * x + matrix[4] * y + matrix[8] * z + matrix[12] * iw,
      matrix[1] * x + matrix[5] * y + matrix[9] * z + matrix[13] * iw,
      matrix[2] * x + matrix[6] * y + matrix[10] * z + matrix[14] * iw,
      matrix[3] * x + matrix[7] * y + matrix[11] * z + matrix[15] * iw
    ];
  }

  function getWorldSize(metrics) {
    return {
      width: State.world.cols * metrics.tileWidth,
      depth: State.world.rows * metrics.tileHeight
    };
  }


  function getWorldCenter(metrics) {
    const size = getWorldSize(metrics);
    return {
      x: size.width / 2,
      z: size.depth / 2
    };
  }

  function rotateAroundCenter(x, z, angleRad, center) {
    const dx = x - center.x;
    const dz = z - center.z;
    const cosA = Math.cos(angleRad);
    const sinA = Math.sin(angleRad);
    return {
      x: center.x + dx * cosA - dz * sinA,
      z: center.z + dx * sinA + dz * cosA
    };
  }

  function logicalToRenderXZ(x, z) {
    const metrics = getGridMetrics();
    return rotateAroundCenter(x, z, degToRad(WORLD_ROTATION_DEGREES), getWorldCenter(metrics));
  }

  function renderToLogicalXZ(x, z) {
    const metrics = getGridMetrics();
    return rotateAroundCenter(x, z, degToRad(-WORLD_ROTATION_DEGREES), getWorldCenter(metrics));
  }


  function convertRenderDeltaToCameraDelta(renderDx, renderDz) {
    const angleRad = degToRad(WORLD_ROTATION_DEGREES);
    const cosA = Math.cos(angleRad);
    const sinA = Math.sin(angleRad);

    const logicalDx = renderDx * cosA + renderDz * sinA;
    const logicalDz = -renderDx * sinA + renderDz * cosA;

    return {
      dx: -logicalDx,
      dy: -logicalDz
    };
  }

  function getCameraTarget(metrics) {
    const size = getWorldSize(metrics);
    return {
      x: size.width / 2 - State.camera.x,
      z: size.depth / 2 - State.camera.y
    };
  }

  function getCameraDistance(metrics, aspect, pitchRad) {
    const size = getWorldSize(metrics);
    const zoom = Math.max(State.camera.zoom || 1, 0.01);
    const depthStrength = Math.max(0.05, State.camera.depthStrength || 1);

    const fovY = degToRad(45);
    const fovX = 2 * Math.atan(Math.tan(fovY / 2) * Math.max(0.001, aspect));

    const fitWidthDistance = (size.width * 0.5) / Math.tan(fovX / 2);
    const projectedDepth = (size.depth * 0.5) * Math.max(0.2, Math.sin(pitchRad));
    const fitDepthDistance = projectedDepth / Math.tan(fovY / 2);

    const baseDistance = Math.max(fitWidthDistance, fitDepthDistance);
    const depthFactor = 0.72 + depthStrength * 0.08;

    return (baseDistance * depthFactor) / zoom;
  }

  function getProjectionData() {
    const canvas = State.dom.canvas;
    const metrics = getGridMetrics();
    const aspect = Math.max(0.001, canvas.clientWidth / Math.max(1, canvas.clientHeight));
    const pitchRad = degToRad(clampPitch(State.camera.pitchAngle || 90));
    const target = getCameraTarget(metrics);
    const renderTarget = logicalToRenderXZ(target.x, target.z);
    const distance = getCameraDistance(metrics, aspect, pitchRad);
    const eye = [
      renderTarget.x,
      Math.max(2, Math.sin(pitchRad) * distance),
      renderTarget.z + Math.max(2, Math.cos(pitchRad) * distance)
    ];
    const targetVec = [renderTarget.x, WORLD_SURFACE_Y, renderTarget.z];
    const up = [0, 1, 0];

    const size = getWorldSize(metrics);
    const far = Math.max(4000, distance + Math.max(size.width, size.depth) * 4);
    const projection = mat4Perspective(degToRad(45), aspect, 0.1, far);
    const view = mat4LookAt(eye, targetVec, up);
    const viewProjection = mat4Multiply(projection, view);
    const inverseViewProjection = mat4Invert(viewProjection) || mat4Identity();

    return {
      metrics,
      eye,
      target: targetVec,
      projection,
      view,
      viewProjection,
      inverseViewProjection,
      canvasWidth: canvas.clientWidth,
      canvasHeight: canvas.clientHeight
    };
  }

  function projectWorldToScreen(worldX, worldY, worldZ) {
    const pd = getProjectionData();
    const rotated = logicalToRenderXZ(worldX, worldZ);
    const clip = transformPoint(pd.viewProjection, rotated.x, worldY, rotated.z, 1);
    const invW = Math.abs(clip[3]) > EPSILON ? 1 / clip[3] : 1;
    const ndcX = clip[0] * invW;
    const ndcY = clip[1] * invW;
    return {
      x: ((ndcX + 1) * 0.5) * pd.canvasWidth,
      y: ((1 - ndcY) * 0.5) * pd.canvasHeight,
      visible: clip[3] > 0
    };
  }

  function screenToWorldOnGround(screenX, screenY) {
    const pd = getProjectionData();
    const ndcX = (screenX / Math.max(1, pd.canvasWidth)) * 2 - 1;
    const ndcY = 1 - (screenY / Math.max(1, pd.canvasHeight)) * 2;

    const nearPoint = transformPoint(pd.inverseViewProjection, ndcX, ndcY, -1, 1);
    const farPoint = transformPoint(pd.inverseViewProjection, ndcX, ndcY, 1, 1);

    const near = [nearPoint[0] / nearPoint[3], nearPoint[1] / nearPoint[3], nearPoint[2] / nearPoint[3]];
    const far = [farPoint[0] / farPoint[3], farPoint[1] / farPoint[3], farPoint[2] / farPoint[3]];
    const direction = vec3Subtract(far, near);

    if (Math.abs(direction[1]) < EPSILON) return null;
    const t = (WORLD_SURFACE_Y - near[1]) / direction[1];
    if (t < 0) return null;

    const renderHit = {
      x: near[0] + direction[0] * t,
      z: near[2] + direction[2] * t
    };
    return renderToLogicalXZ(renderHit.x, renderHit.z);
  }

  function gridToWorld(row, col, tileWidth) {
    const metrics = getGridMetrics(tileWidth);
    return {
      x: col * metrics.tileWidth + metrics.halfW,
      z: row * metrics.tileHeight + metrics.halfH
    };
  }

  function gridToScreen(row, col, offsetX, offsetY, tileWidth) {
    const world = gridToWorld(row, col, tileWidth);
    const projected = projectWorldToScreen(world.x, WORLD_SURFACE_Y, world.z);
    return {
      x: projected.x + (offsetX || 0),
      y: projected.y + (offsetY || 0)
    };
  }

  function screenToGridFloat(x, y) {
    const hit = screenToWorldOnGround(x, y);
    if (!hit) return { row: -1, col: -1 };
    const metrics = getGridMetrics();
    return {
      row: hit.z / metrics.tileHeight - 0.5,
      col: hit.x / metrics.tileWidth - 0.5
    };
  }

  function pointInRect(px, py, cx, cy, tileWidth) {
    const metrics = getGridMetrics(tileWidth);
    return Math.abs(px - cx) <= metrics.halfW && Math.abs(py - cy) <= metrics.halfH;
  }

  function centerCameraOnWorld(x, z) {
    const metrics = getGridMetrics();
    const size = getWorldSize(metrics);
    const nextX = size.width / 2 - x;
    const nextY = size.depth / 2 - z;
    if (Math.abs(State.camera.x - nextX) > 0.01 || Math.abs(State.camera.y - nextY) > 0.01) {
      State.camera.x = nextX;
      State.camera.y = nextY;
      State.render.needsWorldRedraw = true;
    }
  }

  function getPlayerWorldPosition() {
    const player = State.world.player;
    if (!player) return { x: 0, z: 0 };
    if (!player.moving) return gridToWorld(player.row, player.col, 0);

    const start = gridToWorld(player.startRow, player.startCol, 0);
    const end = gridToWorld(player.targetRow, player.targetCol, 0);
    const t = Math.max(0, Math.min(1, player.progress || 0));
    return {
      x: start.x + (end.x - start.x) * t,
      z: start.z + (end.z - start.z) * t
    };
  }

  function centerCameraOnTile(row, col) {
    const pos = gridToWorld(row, col, 0);
    centerCameraOnWorld(pos.x, pos.z);
  }

  function centerCamera() {
    const p = getPlayerWorldPosition();
    centerCameraOnWorld(p.x, p.z);
  }

  function calculateFitZoom() {
    return 1;
  }

  function updateZoomLimits() {
    const camera = State.camera;
    camera.minZoom = 2.00;
    if (camera.maxZoom <= camera.minZoom) {
      camera.maxZoom = Math.max(camera.minZoom + 0.5, 4.00);
    }
    if (camera.zoom < camera.minZoom) camera.zoom = camera.minZoom;
  }

  function fitCameraToWorld() {
    updateZoomLimits();
    State.camera.zoom = Math.max(State.camera.minZoom, Math.min(Config.DEFAULT_START_ZOOM || 0.8, State.camera.maxZoom));
    centerCamera();
    markDirty();
  }

  function updateCameraFollow() {
    if (State.camera.followPlayer && State.world.player && State.world.player.moving) centerCamera();
  }

  function markDirty(worldDirty = true, minimapDirty = true) {
    const render = State.render || {};
    if (worldDirty !== false) render.needsWorldRedraw = true;
    if (minimapDirty !== false) render.needsMinimapRedraw = true;
  }

  function resizeCanvas() {
    const dom = State.dom;
    const gl = dom.gl;
    const dpr = window.devicePixelRatio || 1;
    const displayWidth = Math.round(dom.canvas.clientWidth * dpr);
    const displayHeight = Math.round(dom.canvas.clientHeight * dpr);
    if (dom.canvas.width !== displayWidth || dom.canvas.height !== displayHeight) {
      dom.canvas.width = displayWidth;
      dom.canvas.height = displayHeight;
    }
    initializeWebGLResources();
    syncTerrainShapeOverlaySize();
    gl.viewport(0, 0, dom.canvas.width, dom.canvas.height);
    updateZoomLimits();
    State.render.needsWorldRedraw = true;
  }

  function pickTile(x, y) {
    const world = State.world;
    const guess = screenToGridFloat(x, y);
    const row = Math.round(guess.row);
    const col = Math.round(guess.col);
    if (row < 0 || col < 0 || row >= world.rows || col >= world.cols) return null;
    return { row, col };
  }

  function terrainColor(tile) {
    switch (tile.type) {
      case "grass": return "#5a9b5f";
      case "dirt": return "#a57b4e";
      case "mountain": return "#8a8e96";
      case "lake": return "#4b79b4";
      case "river": return "#4b79b4";
      case "road": return "#b99b68";
      case "forest": return "#3f6f45";
      case "settlement": return "#c9b48d";
      default: return "#5a9b5f";
    }
  }


  function hexToRgb(hex) {
    const cleaned = hex.replace("#", "");
    const value = parseInt(cleaned, 16);
    return {
      r: (value >> 16) & 255,
      g: (value >> 8) & 255,
      b: value & 255
    };
  }

  function mixRgb(a, b, t) {
    return {
      r: Math.round(a.r + (b.r - a.r) * t),
      g: Math.round(a.g + (b.g - a.g) * t),
      b: Math.round(a.b + (b.b - a.b) * t)
    };
  }


  function clamp01(value) {
    return Math.max(0, Math.min(1, value));
  }

  function clampByte(value) {
    return Math.max(0, Math.min(255, Math.round(value)));
  }

  function scaleRgb(color, factor) {
    return {
      r: clampByte(color.r * factor),
      g: clampByte(color.g * factor),
      b: clampByte(color.b * factor)
    };
  }

  function addRgb(color, amount) {
    return {
      r: clampByte(color.r + amount),
      g: clampByte(color.g + amount),
      b: clampByte(color.b + amount)
    };
  }

  function getTile(row, col) {
    const terrainRow = State.world.terrain[row];
    return terrainRow && terrainRow[col] ? terrainRow[col] : null;
  }

  function getRenderLevel(tile, row, col) {
    if (!tile) return 1;
    const effectiveType = Number.isInteger(row) && Number.isInteger(col) ? getTileType(row, col) : tile.type;
    if (effectiveType === "lake" || effectiveType === "river") {
      return 0;
    }
    if (effectiveType === "mountain") {
      return 3;
    }
    if (effectiveType === "forest") {
      return 2;
    }
    if (effectiveType === "road" || effectiveType === "grass" || effectiveType === "dirt" || effectiveType === "settlement") {
      return 1;
    }
    return 1;
  }

  function getSunDirection() {
    const azimuth = degToRad(State.camera.sunAzimuth || 0);
    return {
      x: Math.cos(azimuth),
      y: Math.sin(azimuth)
    };
  }

  function sampleLevelAt(rowFloat, colFloat) {
    const world = State.world;
    const row = Math.max(0, Math.min(world.rows - 1, Math.floor(rowFloat)));
    const col = Math.max(0, Math.min(world.cols - 1, Math.floor(colFloat)));
    return getRenderLevel(getTile(row, col));
  }

  function sampleTypeAt(rowFloat, colFloat) {
    const world = State.world;
    const row = Math.max(0, Math.min(world.rows - 1, Math.floor(rowFloat)));
    const col = Math.max(0, Math.min(world.cols - 1, Math.floor(colFloat)));
    return getTileType(row, col);
  }

  function distanceToTypeBoundary(rowFloat, colFloat, dirY, dirX, targetType, maxDistance, stepSize) {
    let lastInside = 0;
    for (let t = stepSize; t <= maxDistance; t += stepSize) {
      const sampleRow = rowFloat + dirY * t;
      const sampleCol = colFloat + dirX * t;
      if (sampleTypeAt(sampleRow, sampleCol) !== targetType) {
        return t;
      }
      lastInside = t;
    }
    return Math.min(maxDistance, lastInside + stepSize);
  }

  function computeMountainGroupRelief(seed, rowFloat, colFloat, baseRow, baseCol, sun) {
    const currentType = sampleTypeAt(baseRow + 0.001, baseCol + 0.001);
    if (currentType !== 'mountain') {
      return null;
    }

    const maxDistance = 3.2;
    const stepSize = 0.18;

    const facingBoundaryDistance = distanceToTypeBoundary(
      rowFloat,
      colFloat,
      sun.y,
      sun.x,
      'mountain',
      maxDistance,
      stepSize
    );

    const facingOpenLevel = sampleLevelAt(
      rowFloat + sun.y * Math.min(facingBoundaryDistance + 0.2, maxDistance),
      colFloat + sun.x * Math.min(facingBoundaryDistance + 0.2, maxDistance)
    );

    const currentLevel = getRenderLevel(getTile(baseRow, baseCol));
    const edgeHighlight = clamp01(1 - ((facingBoundaryDistance - stepSize) / maxDistance));

    let highlightAmount = edgeHighlight * clamp01((currentLevel - facingOpenLevel) / 3);

    const sunElevation = degToRad(State.camera.sunElevation || 45);
    const elevationHighlightScale = 0.55 + clamp01(sunElevation / (Math.PI / 2)) * 0.45;
    const noise = RNG.hashNoise(
      seed,
      Math.floor(rowFloat * 977) + baseRow * 11,
      Math.floor(colFloat * 983) + baseCol * 17,
      'relief-light'
    );
    const noiseFactor = 0.94 + noise * 0.12;

    return {
      shadowAmount: 0,
      highlightAmount: clamp01(highlightAmount * elevationHighlightScale * noiseFactor),
      edgeAmount: edgeHighlight
    };
  }

  function computeReliefLight(seed, rowFloat, colFloat) {
    if (!State.camera.reliefEnabled) {
      return { shadowAmount: 0, highlightAmount: 0, edgeAmount: 0 };
    }

    const world = State.world;
    const baseRow = Math.max(0, Math.min(world.rows - 1, Math.floor(rowFloat)));
    const baseCol = Math.max(0, Math.min(world.cols - 1, Math.floor(colFloat)));
    const currentTile = getTile(baseRow, baseCol);
    const currentLevel = getRenderLevel(currentTile, baseRow, baseCol);
    const sun = getSunDirection();

    if (currentTile && getTileType(baseRow, baseCol) === 'mountain') {
      const mountainRelief = computeMountainGroupRelief(seed, rowFloat, colFloat, baseRow, baseCol, sun);
      if (mountainRelief) {
        return mountainRelief;
      }
    }

    const shadowMaxDistance = Math.max(0.5, Number(State.camera.shadowLength) || 5.4);
    const shadowStepSize = 0.18;
    let firstHigherDistance = null;

    for (let t = shadowStepSize; t <= shadowMaxDistance; t += shadowStepSize) {
      const sampleRow = rowFloat + sun.y * t;
      const sampleCol = colFloat + sun.x * t;

      if (sampleRow < 0 || sampleCol < 0 || sampleRow >= world.rows || sampleCol >= world.cols) {
        break;
      }

      const sampleTile = getTile(Math.floor(sampleRow), Math.floor(sampleCol));
      const sampleLevel = getRenderLevel(sampleTile, Math.floor(sampleRow), Math.floor(sampleCol));
      if (sampleLevel > currentLevel) {
        firstHigherDistance = t;
        break;
      }
    }

    if (firstHigherDistance === null) {
      return { shadowAmount: 0, highlightAmount: 0, edgeAmount: 0 };
    }

    const shadowEdgeAmount = clamp01(1 - ((firstHigherDistance - shadowStepSize) / shadowMaxDistance));

    let shadowDiff = 0;
    const sampleSteps = [0.65, 1.35, 2.05];
    for (let i = 0; i < sampleSteps.length; i++) {
      const step = sampleSteps[i];
      const weight = i === 0 ? 1.0 : (i === 1 ? 0.65 : 0.35);

      const blockerLevel = sampleLevelAt(
        rowFloat + sun.y * (firstHigherDistance + step),
        colFloat + sun.x * (firstHigherDistance + step)
      );

      shadowDiff += Math.max(0, blockerLevel - currentLevel) * weight;
    }

    const sunElevation = degToRad(State.camera.sunElevation || 45);
    const elevationShadowScale = 1.05 - clamp01(sunElevation / (Math.PI / 2)) * 0.55;
    const noise = RNG.hashNoise(
      seed,
      Math.floor(rowFloat * 977) + baseRow * 11,
      Math.floor(colFloat * 983) + baseCol * 17,
      'relief-light'
    );
    const noiseFactor = 0.94 + noise * 0.12;

    return {
      shadowAmount: clamp01((shadowDiff / 3) * elevationShadowScale * noiseFactor * shadowEdgeAmount),
      highlightAmount: 0,
      edgeAmount: shadowEdgeAmount
    };
  }

  function applyReliefLighting(baseColor, lightInfo) {
    if (!State.camera.reliefEnabled) return baseColor;
    // Use camera values when present, otherwise fall back to config defaults
    const shadowStrength = Math.max(0, Number((State.camera && State.camera.shadowStrength != null) ? State.camera.shadowStrength : Config.DEFAULT_SHADOW_STRENGTH) || 0);
    const highlightStrength = Math.max(0, Number((State.camera && State.camera.highlightStrength != null) ? State.camera.highlightStrength : Config.DEFAULT_HIGHLIGHT_STRENGTH) || 0);
    const shadowFactor = 1 - (lightInfo.shadowAmount * shadowStrength * (0.65 + lightInfo.edgeAmount * 0.35));
    const highlightAmount = lightInfo.highlightAmount * highlightStrength * (0.35 + lightInfo.edgeAmount * 0.65) * 72;
    const shadowed = scaleRgb(baseColor, shadowFactor);
    return addRgb(shadowed, highlightAmount);
  }


  function luminance(color) {
    return color.r * 0.2126 + color.g * 0.7152 + color.b * 0.0722;
  }

  function getPixelColor(pixels, width, x, y) {
    const safeX = Math.max(0, Math.min(width - 1, x));
    const safeY = Math.max(0, Math.min(State.render.worldBackgroundCanvas.height - 1, y));
    const idx = (safeY * width + safeX) * 4;
    return {
      r: pixels[idx],
      g: pixels[idx + 1],
      b: pixels[idx + 2]
    };
  }

  function writeRect(pixels, width, x0, y0, x1, y1, color) {
    const minX = Math.max(0, Math.floor(x0));
    const minY = Math.max(0, Math.floor(y0));
    const maxX = Math.min(width, Math.ceil(x1));
    const maxY = Math.min(State.render.worldBackgroundCanvas.height, Math.ceil(y1));
    for (let py = minY; py < maxY; py++) {
      for (let px = minX; px < maxX; px++) {
        const idx = (py * width + px) * 4;
        pixels[idx] = color.r;
        pixels[idx + 1] = color.g;
        pixels[idx + 2] = color.b;
        pixels[idx + 3] = 255;
      }
    }
  }

  function pickNoiseLevel(levels, noiseValue) {
    const scaled = Math.floor(clamp01(noiseValue) * levels.length);
    const index = Math.max(0, Math.min(levels.length - 1, scaled >= levels.length ? levels.length - 1 : scaled));
    return levels[index];
  }

  function applyPostTileNoise(pixels, canvasWidth, canvasHeight, cellWidth, cellHeight, seed) {
    const world = State.world;
    const divisions = Math.max(1, Math.round(State.camera.noiseGridDivisions || 1));

    for (let row = 0; row < world.rows; row++) {
      const y0 = row * cellHeight;
      const y1 = (row + 1) * cellHeight;
      for (let col = 0; col < world.cols; col++) {
        const x0 = col * cellWidth;
        const x1 = (col + 1) * cellWidth;

        for (let gy = 0; gy < divisions; gy++) {
          const gy0 = y0 + (y1 - y0) * (gy / divisions);
          const gy1 = y0 + (y1 - y0) * ((gy + 1) / divisions);
          for (let gx = 0; gx < divisions; gx++) {
            const gx0 = x0 + (x1 - x0) * (gx / divisions);
            const gx1 = x0 + (x1 - x0) * ((gx + 1) / divisions);
            const sampleX = Math.max(0, Math.min(canvasWidth - 1, Math.floor((gx0 + gx1) * 0.5)));
            const sampleY = Math.max(0, Math.min(canvasHeight - 1, Math.floor((gy0 + gy1) * 0.5)));
            const rowFloat = (sampleY + 0.5) / cellHeight;
            const colFloat = (sampleX + 0.5) / cellWidth;

            const currentColor = getPixelColor(pixels, canvasWidth, sampleX, sampleY);
            const blendedBase = buildBlendColor(seed, rowFloat, colFloat);
            const currentLum = luminance(currentColor);
            const baseLum = luminance(blendedBase);
            const diff = currentLum - baseLum;
            const shadeNoise = RNG.hashNoise(seed, row * 991 + gy * 41, col * 977 + gx * 59, `tile-noise|${divisions}`);

            let delta;
            if (diff < -6) {
              const shadowLevels = [-20, -16, -12, -8, -5];
              delta = pickNoiseLevel(shadowLevels, shadeNoise);
            } else if (diff > 6) {
              const lightLevels = [5, 8, 12, 16, 20];
              delta = pickNoiseLevel(lightLevels, shadeNoise);
            } else {
              const midLevels = [-8, -4, 0, 4, 8];
              delta = pickNoiseLevel(midLevels, shadeNoise);
            }

            writeRect(pixels, canvasWidth, gx0, gy0, gx1, gy1, addRgb(currentColor, delta));
          }
        }
      }
    }
  }

  function writeBlock(pixels, canvasWidth, x0, y0, size, color) {
    const maxX = Math.min(canvasWidth, x0 + size);
    const maxY = Math.min(State.render.worldBackgroundCanvas.height, y0 + size);
    for (let y = y0; y < maxY; y++) {
      for (let x = x0; x < maxX; x++) {
        const idx = (y * canvasWidth + x) * 4;
        pixels[idx] = color.r;
        pixels[idx + 1] = color.g;
        pixels[idx + 2] = color.b;
        pixels[idx + 3] = 255;
      }
    }
  }

  function getRawTileType(row, col) {
    const terrainRow = State.world.terrain[row];
    const tile = terrainRow && terrainRow[col];
    return tile ? tile.type : null;
  }

  function isRoadClearanceTile(row, col) {
    const tile = getTile(row, col);
    if (!tile || tile.type === 'road' || tile.type === 'settlement') return false;

    const isBlockedTerrain = tile.type === 'forest'
      || tile.type === 'mountain'
      || tile.type === 'lake'
      || tile.type === 'river'
      || !!(tile.tags && (tile.tags.has('blocked') || tile.tags.has('forest') || tile.tags.has('mountain') || tile.tags.has('lake') || tile.tags.has('stream')));
    if (!isBlockedTerrain) return false;

    for (let nr = row - 1; nr <= row + 1; nr++) {
      for (let nc = col - 1; nc <= col + 1; nc++) {
        if (nr === row && nc === col) continue;
        if (getRawTileType(nr, nc) === 'road') return true;
      }
    }
    return false;
  }

  function getTileType(row, col) {
    const rawType = getRawTileType(row, col);
    if (!rawType) return null;
    if (isRoadClearanceTile(row, col)) return 'grass';
    return rawType;
  }

  function getRoadAppearanceCache() {
    const render = State.render;
    if (!render.roadAppearanceCache) {
      render.roadAppearanceCache = new Map();
    }
    return render.roadAppearanceCache;
  }

  function getRoadBaseAppearance(row, col) {
    const cache = getRoadAppearanceCache();
    const key = `${row},${col}`;
    if (cache.has(key)) return cache.get(key);

    const tile = getTile(row, col);
    const baseElevation = tile ? Number(tile.elevation || 0) : 0;
    const neighborColors = [];
    const neighborWeights = [];
    const typeWeights = Object.create(null);

    for (let nr = row - 1; nr <= row + 1; nr++) {
      for (let nc = col - 1; nc <= col + 1; nc++) {
        if (nr === row && nc === col) continue;
        const neighbor = getTile(nr, nc);
        if (!neighbor) continue;
        const neighborType = getTileType(nr, nc);
        if (neighborType === 'road') continue;
        if (neighborType === 'lake' || neighborType === 'river') continue;
        if (Math.abs(Number(neighbor.elevation || 0) - baseElevation) > 0.001) continue;

        const isDiagonal = nr !== row && nc !== col;
        const weight = isDiagonal ? 0.7 : 1.0;
        neighborColors.push(hexToRgb(terrainColor({ type: neighborType })));
        neighborWeights.push(weight);
        typeWeights[neighborType] = (typeWeights[neighborType] || 0) + weight;
      }
    }

    let dominantType = 'grass';
    let dominantWeight = -1;
    Object.keys(typeWeights).forEach((type) => {
      if (typeWeights[type] > dominantWeight) {
        dominantWeight = typeWeights[type];
        dominantType = type;
      }
    });

    const appearance = {
      type: dominantType,
      color: neighborColors.length
        ? averageRgb(neighborColors, neighborWeights)
        : hexToRgb(terrainColor({ type: dominantType }))
    };

    cache.set(key, appearance);
    return appearance;
  }

  function getVisualTileAppearance(row, col) {
    const tile = getTile(row, col);
    if (!tile) {
      return { type: 'grass', color: hexToRgb(terrainColor({ type: 'grass' })) };
    }
    const effectiveType = getTileType(row, col);
    if (effectiveType === 'road') {
      return getRoadBaseAppearance(row, col);
    }
    return {
      type: effectiveType,
      color: hexToRgb(terrainColor({ type: effectiveType }))
    };
  }

  function smoothstep01(t) {
    const x = Math.max(0, Math.min(1, t));
    return x * x * (3 - 2 * x);
  }

  function distanceToTileRect(rowFloat, colFloat, tileRow, tileCol) {
    const minX = tileCol;
    const maxX = tileCol + 1;
    const minY = tileRow;
    const maxY = tileRow + 1;
    const dx = colFloat < minX ? (minX - colFloat) : (colFloat > maxX ? colFloat - maxX : 0);
    const dy = rowFloat < minY ? (minY - rowFloat) : (rowFloat > maxY ? rowFloat - maxY : 0);
    return Math.hypot(dx, dy);
  }

  function averageRgb(colors, weights) {
    let total = 0;
    let r = 0;
    let g = 0;
    let b = 0;
    for (let i = 0; i < colors.length; i++) {
      const w = weights[i];
      total += w;
      r += colors[i].r * w;
      g += colors[i].g * w;
      b += colors[i].b * w;
    }
    if (total <= 0) return colors[0];
    return {
      r: Math.round(r / total),
      g: Math.round(g / total),
      b: Math.round(b / total)
    };
  }

  function buildBlendColor(seed, rowFloat, colFloat) {
    const world = State.world;
    const baseRow = Math.max(0, Math.min(world.rows - 1, Math.floor(rowFloat)));
    const baseCol = Math.max(0, Math.min(world.cols - 1, Math.floor(colFloat)));
    const baseAppearance = getVisualTileAppearance(baseRow, baseCol);
    const baseType = baseAppearance.type;
    const baseColor = baseAppearance.color;
    const blendStrength = Math.max(0, Math.min(0.5, State.camera.blendStrength || 0));
    if (blendStrength <= 0) return baseColor;

    const neighborColors = [];
    const neighborWeights = [];
    let strongestNeighbor = 0;

    for (let row = baseRow - 1; row <= baseRow + 1; row++) {
      for (let col = baseCol - 1; col <= baseCol + 1; col++) {
        if (row < 0 || col < 0 || row >= world.rows || col >= world.cols) continue;
        if (row === baseRow && col === baseCol) continue;

        // Skip diagonal neighbors to avoid corner-only color bleed
        // which can make isolated diagonal tiles (singletons) visually
        // appear as part of the base tile. Use orthogonal neighbors only.
        if (row !== baseRow && col !== baseCol) continue;

        const neighborAppearance = getVisualTileAppearance(row, col);
        const type = neighborAppearance.type;
        if (!type || type === baseType) continue;

        const distance = distanceToTileRect(rowFloat, colFloat, row, col);
        if (distance >= blendStrength) continue;

        const proximity = 1 - (distance / blendStrength);
        let weight = smoothstep01(proximity);
        if (weight <= 0) continue;

        const noise = RNG.hashNoise(
          seed,
          Math.floor(rowFloat * 997) + row * 31,
          Math.floor(colFloat * 991) + col * 17,
          `blend-weight|${row}|${col}|${type}`
        );
        weight *= 0.82 + noise * 0.36;
        strongestNeighbor = Math.max(strongestNeighbor, weight);
        neighborColors.push(neighborAppearance.color);
        neighborWeights.push(weight);
      }
    }

    if (!neighborWeights.length) return baseColor;

    const neighborColor = averageRgb(neighborColors, neighborWeights);
    const mixNoise = RNG.hashNoise(
      seed,
      Math.floor(rowFloat * 1237) + baseRow * 43,
      Math.floor(colFloat * 1291) + baseCol * 19,
      `blend-mix`
    );

    const t = Math.max(0, Math.min(0.5, strongestNeighbor * (0.9 + mixNoise * 0.2) * 0.5));
    return mixRgb(baseColor, neighborColor, t);
  }

  function hexToNormalizedRgba(hex, alpha) {
    const cleaned = hex.replace("#", "");
    const value = parseInt(cleaned, 16);
    return [
      ((value >> 16) & 255) / 255,
      ((value >> 8) & 255) / 255,
      (value & 255) / 255,
      alpha !== undefined ? alpha : 1
    ];
  }

  function setCustomColor(gl, rgba) {
    gl.uniform4f(State.render.colorLocation, rgba[0], rgba[1], rgba[2], rgba[3]);
  }

  function useColorProgram(gl) {
    const render = State.render;
    gl.useProgram(render.colorProgram);
    gl.uniformMatrix4fv(render.colorMatrixLocation, false, getProjectionData().viewProjection);
    gl.bindBuffer(gl.ARRAY_BUFFER, render.positionBuffer);
    gl.enableVertexAttribArray(render.colorPositionLocation);
    gl.vertexAttribPointer(render.colorPositionLocation, 3, gl.FLOAT, false, 0, 0);
  }

  function useTextureProgram(gl) {
    const render = State.render;
    gl.useProgram(render.textureProgram);
    gl.uniformMatrix4fv(render.textureMatrixLocation, false, getProjectionData().viewProjection);
    gl.bindBuffer(gl.ARRAY_BUFFER, render.texturePositionBuffer);
    gl.enableVertexAttribArray(render.texturePositionLocation);
    gl.vertexAttribPointer(render.texturePositionLocation, 3, gl.FLOAT, false, 0, 0);
  }

  function drawTriangles(gl, vertices, rgba) {
    useColorProgram(gl);
    gl.bindBuffer(gl.ARRAY_BUFFER, State.render.positionBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(vertices), gl.STREAM_DRAW);
    setCustomColor(gl, rgba);
    gl.drawArrays(gl.TRIANGLES, 0, vertices.length / 3);
  }

  function drawLineLoop(gl, vertices, rgba) {
    useColorProgram(gl);
    gl.bindBuffer(gl.ARRAY_BUFFER, State.render.positionBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(vertices), gl.STREAM_DRAW);
    setCustomColor(gl, rgba);
    gl.drawArrays(gl.LINE_LOOP, 0, vertices.length / 3);
  }

  function drawLines(gl, vertices, rgba) {
    if (!vertices || !vertices.length) return;
    useColorProgram(gl);
    gl.bindBuffer(gl.ARRAY_BUFFER, State.render.positionBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(vertices), gl.STREAM_DRAW);
    setCustomColor(gl, rgba);
    gl.drawArrays(gl.LINES, 0, vertices.length / 3);
  }

  function drawEllipse2D(gl, cx, cy, radiusX, radiusY, rgba, segments) {
    const count = Math.max(12, segments || 24);
    const vertices = [];
    for (let i = 0; i < count; i++) {
      const a0 = (i / count) * Math.PI * 2;
      const a1 = ((i + 1) / count) * Math.PI * 2;
      vertices.push(
        cx, cy,
        cx + Math.cos(a0) * radiusX, cy + Math.sin(a0) * radiusY,
        cx + Math.cos(a1) * radiusX, cy + Math.sin(a1) * radiusY
      );
    }

    const triangles3D = [];
    for (let i = 0; i < vertices.length; i += 2) {
      triangles3D.push(vertices[i], vertices[i + 1], 0);
    }
    useColorProgramScreenSpace(gl);
    gl.bindBuffer(gl.ARRAY_BUFFER, State.render.positionBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(triangles3D), gl.STREAM_DRAW);
    setCustomColor(gl, rgba);
    gl.drawArrays(gl.TRIANGLES, 0, triangles3D.length / 3);
  }

  function useColorProgramScreenSpace(gl) {
    const render = State.render;
    gl.useProgram(render.colorProgram);
    gl.uniformMatrix4fv(render.colorMatrixLocation, false, getScreenSpaceMatrix());
    gl.bindBuffer(gl.ARRAY_BUFFER, render.positionBuffer);
    gl.enableVertexAttribArray(render.colorPositionLocation);
    gl.vertexAttribPointer(render.colorPositionLocation, 3, gl.FLOAT, false, 0, 0);
  }

  function getScreenSpaceMatrix() {
    const w = Math.max(1, State.dom.canvas.clientWidth);
    const h = Math.max(1, State.dom.canvas.clientHeight);
    return new Float32Array([
      2 / w, 0, 0, 0,
      0, -2 / h, 0, 0,
      0, 0, 1, 0,
      -1, 1, 0, 1
    ]);
  }

  function drawCapsule2D(gl, x1, y1, x2, y2, radius, rgba) {
    const dx = x2 - x1;
    const dy = y2 - y1;
    const length = Math.hypot(dx, dy);
    if (length < EPSILON) {
      drawEllipse2D(gl, x1, y1, radius, radius, rgba, 20);
      return;
    }

    const nx = -dy / length;
    const ny = dx / length;
    const vertices = [
      x1 + nx * radius, y1 + ny * radius, 0,
      x1 - nx * radius, y1 - ny * radius, 0,
      x2 + nx * radius, y2 + ny * radius, 0,
      x2 + nx * radius, y2 + ny * radius, 0,
      x1 - nx * radius, y1 - ny * radius, 0,
      x2 - nx * radius, y2 - ny * radius, 0
    ];
    useColorProgramScreenSpace(gl);
    gl.bindBuffer(gl.ARRAY_BUFFER, State.render.positionBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(vertices), gl.STREAM_DRAW);
    setCustomColor(gl, rgba);
    gl.drawArrays(gl.TRIANGLES, 0, vertices.length / 3);
    drawEllipse2D(gl, x1, y1, radius, radius, rgba, 20);
    drawEllipse2D(gl, x2, y2, radius, radius, rgba, 20);
  }

  function getRectOutlineVertices3D(centerX, centerZ, width, depth, y) {
    const halfW = width / 2;
    const halfD = depth / 2;
    const corners = [
      { x: centerX - halfW, z: centerZ - halfD },
      { x: centerX + halfW, z: centerZ - halfD },
      { x: centerX + halfW, z: centerZ + halfD },
      { x: centerX - halfW, z: centerZ + halfD }
    ].map((point) => logicalToRenderXZ(point.x, point.z));

    return [
      corners[0].x, y, corners[0].z,
      corners[1].x, y, corners[1].z,
      corners[2].x, y, corners[2].z,
      corners[3].x, y, corners[3].z
    ];
  }

  function drawSelectionMarker(gl, row, col, tileWidth, tileHeight) {
    const pos = gridToWorld(row, col, tileWidth);
    drawLineLoop(gl, getRectOutlineVertices3D(pos.x, pos.z, tileWidth * 0.62, tileHeight * 0.62, MARKER_Y), [0.97, 0.87, 0.48, 1]);
  }

  function drawHoverMarker(gl, row, col, tileWidth, tileHeight) {
    const pos = gridToWorld(row, col, tileWidth);
    drawLineLoop(gl, getRectOutlineVertices3D(pos.x, pos.z, tileWidth * 0.92, tileHeight * 0.92, MARKER_Y), [0.97, 0.87, 0.48, 0.65]);
  }

  function drawArrowMarker(gl, fromRow, fromCol, toRow, toCol, tileWidth, tileHeight) {
    const fromPos = gridToWorld(fromRow, fromCol, tileWidth);
    const toPos = gridToWorld(toRow, toCol, tileWidth);
    const dx = toPos.x - fromPos.x;
    const dz = toPos.z - fromPos.z;
    const length = Math.hypot(dx, dz) || 1;
    const ux = dx / length;
    const uz = dz / length;
    const px = -uz;
    const pz = ux;
    const bodyLength = tileHeight * 0.95;
    const headLength = tileHeight * 0.55;
    const bodyHalf = tileHeight * 0.14;
    const headHalf = tileHeight * 0.28;
    const sx = fromPos.x;
    const sz = fromPos.z;
    const bx = sx + ux * bodyLength;
    const bz = sz + uz * bodyLength;
    const hx = bx + ux * headLength;
    const hz = bz + uz * headLength;
    const y = MARKER_Y;

    const bodyPoints = [
      { x: sx + px * bodyHalf, z: sz + pz * bodyHalf },
      { x: sx - px * bodyHalf, z: sz - pz * bodyHalf },
      { x: bx + px * bodyHalf, z: bz + pz * bodyHalf },
      { x: bx + px * bodyHalf, z: bz + pz * bodyHalf },
      { x: sx - px * bodyHalf, z: sz - pz * bodyHalf },
      { x: bx - px * bodyHalf, z: bz - pz * bodyHalf }
    ].map((point) => logicalToRenderXZ(point.x, point.z));

    drawTriangles(gl, [
      bodyPoints[0].x, y, bodyPoints[0].z,
      bodyPoints[1].x, y, bodyPoints[1].z,
      bodyPoints[2].x, y, bodyPoints[2].z,
      bodyPoints[3].x, y, bodyPoints[3].z,
      bodyPoints[4].x, y, bodyPoints[4].z,
      bodyPoints[5].x, y, bodyPoints[5].z
    ], [0.39, 0.07, 0.18, 0.72]);

    const headPoints = [
      { x: bx + px * headHalf, z: bz + pz * headHalf },
      { x: bx - px * headHalf, z: bz - pz * headHalf },
      { x: hx, z: hz }
    ].map((point) => logicalToRenderXZ(point.x, point.z));

    drawTriangles(gl, [
      headPoints[0].x, y, headPoints[0].z,
      headPoints[1].x, y, headPoints[1].z,
      headPoints[2].x, y, headPoints[2].z
    ], [0.57, 0.13, 0.27, 0.94]);
  }

  function drawPreviewRoute(gl, path, metrics) {
    if (!path || path.length < 2) return;
    for (let i = 0; i < path.length - 1; i++) {
      drawArrowMarker(gl, path[i].row, path[i].col, path[i + 1].row, path[i + 1].col, metrics.tileWidth, metrics.tileHeight);
    }
  }


  function hasRoadAt(row, col) {
    return getRawTileType(row, col) === 'road';
  }

  function shouldRenderRoadConnection(row, col, dr, dc) {
    if (!hasRoadAt(row + dr, col + dc)) return false;

    const isDiagonal = dr !== 0 && dc !== 0;
    if (!isDiagonal) return true;

    const verticalBridgeExists = hasRoadAt(row + dr, col);
    const horizontalBridgeExists = hasRoadAt(row, col + dc);

    if (verticalBridgeExists || horizontalBridgeExists) {
      return false;
    }

    return true;
  }

  function getRoadConnections(row, col) {
    const directions = [
      { dr: -1, dc: 0 },
      { dr: 1, dc: 0 },
      { dr: 0, dc: -1 },
      { dr: 0, dc: 1 },
      { dr: -1, dc: -1 },
      { dr: -1, dc: 1 },
      { dr: 1, dc: -1 },
      { dr: 1, dc: 1 }
    ];
    return directions.filter((dir) => shouldRenderRoadConnection(row, col, dir.dr, dir.dc));
  }

  function drawRoadDisc2D(ctx, centerX, centerY, radius, fillStyle) {
    // Arcs removed: draw a filled square as a replacement for a disc.
    const size = Math.max(1, Math.round(radius * 2));
    ctx.fillStyle = fillStyle;
    ctx.fillRect(Math.round(centerX - radius), Math.round(centerY - radius), size, size);
  }

  function drawRoadCapsule2D(ctx, x1, y1, x2, y2, radius, fillStyle) {
    const dx = x2 - x1;
    const dy = y2 - y1;
    const length = Math.hypot(dx, dy);
    if (length < EPSILON) {
      drawRoadDisc2D(ctx, x1, y1, radius, fillStyle);
      return;
    }

    const ux = dx / length;
    const uy = dy / length;
    const px = -uy;
    const py = ux;

    ctx.beginPath();
    ctx.moveTo(x1 + px * radius, y1 + py * radius);
    ctx.lineTo(x1 - px * radius, y1 - py * radius);
    ctx.lineTo(x2 - px * radius, y2 - py * radius);
    ctx.lineTo(x2 + px * radius, y2 + py * radius);
    ctx.closePath();
    ctx.fillStyle = fillStyle;
    ctx.fill();

    drawRoadDisc2D(ctx, x1, y1, radius, fillStyle);
    drawRoadDisc2D(ctx, x2, y2, radius, fillStyle);
  }

  function rgbToCss(color, alpha) {
    if (alpha === undefined || alpha === null) {
      return `rgb(${clampByte(color.r)}, ${clampByte(color.g)}, ${clampByte(color.b)})`;
    }
    return `rgba(${clampByte(color.r)}, ${clampByte(color.g)}, ${clampByte(color.b)}, ${Math.max(0, Math.min(1, alpha))})`;
  }

  function getRoadShadedAppearance(row, col, seed) {
    const baseRoadRgb = hexToRgb(terrainColor({ type: 'road' }));
    const lightInfo = computeReliefLight(seed, row + 0.5, col + 0.5);
    const fillRgb = applyReliefLighting(baseRoadRgb, lightInfo);
    const edgeRgb = {
      r: Math.max(0, fillRgb.r - 36),
      g: Math.max(0, fillRgb.g - 36),
      b: Math.max(0, fillRgb.b - 36)
    };
    return {
      fillCss: rgbToCss(fillRgb),
      edgeCss: rgbToCss(edgeRgb, 0.28)
    };
  }

  function drawRoadOverlay(ctx, cellWidth, cellHeight) {
    const world = State.world;
    const seed = world.seed || 'road';
    const roadWidth = Math.max(3, Math.min(cellWidth, cellHeight) * 0.34);
    const roadRadius = roadWidth * 0.5;
    const edgeBandWidth = Math.max(0.75, roadWidth * 0.08);
    const edgeRadius = roadRadius + edgeBandWidth;

    const centers = [];
    const segments = [];

    for (let row = 0; row < world.rows; row++) {
      for (let col = 0; col < world.cols; col++) {
        if (getRawTileType(row, col) !== 'road') continue;

        const centerX = (col + 0.5) * cellWidth;
        const centerY = (row + 0.5) * cellHeight;
        const appearance = getRoadShadedAppearance(row, col, seed);
        centers.push({ x: centerX, y: centerY, appearance });

        const connections = getRoadConnections(row, col);
        for (let i = 0; i < connections.length; i++) {
          const dir = connections[i];
          const nr = row + dir.dr;
          const nc = col + dir.dc;
          if (nr < row || (nr === row && nc <= col)) continue;
          const endX = (nc + 0.5) * cellWidth;
          const endY = (nr + 0.5) * cellHeight;
          const neighborAppearance = getRoadShadedAppearance(nr, nc, seed);
          segments.push({
            x1: centerX,
            y1: centerY,
            x2: endX,
            y2: endY,
            startAppearance: appearance,
            endAppearance: neighborAppearance
          });
        }
      }
    }

    for (let i = 0; i < segments.length; i++) {
      const seg = segments[i];
      const edgeGradient = ctx.createLinearGradient(seg.x1, seg.y1, seg.x2, seg.y2);
      edgeGradient.addColorStop(0, seg.startAppearance.edgeCss);
      edgeGradient.addColorStop(1, seg.endAppearance.edgeCss);
      drawRoadCapsule2D(ctx, seg.x1, seg.y1, seg.x2, seg.y2, edgeRadius, edgeGradient);
    }
    for (let i = 0; i < centers.length; i++) {
      const c = centers[i];
      drawRoadDisc2D(ctx, c.x, c.y, edgeRadius, c.appearance.edgeCss);
    }

    for (let i = 0; i < segments.length; i++) {
      const seg = segments[i];
      const fillGradient = ctx.createLinearGradient(seg.x1, seg.y1, seg.x2, seg.y2);
      fillGradient.addColorStop(0, seg.startAppearance.fillCss);
      fillGradient.addColorStop(1, seg.endAppearance.fillCss);
      drawRoadCapsule2D(ctx, seg.x1, seg.y1, seg.x2, seg.y2, roadRadius, fillGradient);
    }
    for (let i = 0; i < centers.length; i++) {
      const c = centers[i];
      drawRoadDisc2D(ctx, c.x, c.y, roadRadius, c.appearance.fillCss);
    }
  }


  function redrawElevatedTerrainOverRoads(ctx, baseImageData, cellWidth, cellHeight) {
    const world = State.world;
    const roadLevel = 1;

    for (let row = 0; row < world.rows; row++) {
      for (let col = 0; col < world.cols; col++) {
        const tile = getTile(row, col);
        if (!tile) continue;
        if (isRoadClearanceTile(row, col)) continue;
        if (getRenderLevel(tile, row, col) <= roadLevel) continue;

        const x = Math.floor(col * cellWidth);
        const y = Math.floor(row * cellHeight);
        const width = Math.max(1, Math.ceil((col + 1) * cellWidth) - x);
        const height = Math.max(1, Math.ceil((row + 1) * cellHeight) - y);
        ctx.putImageData(baseImageData, 0, 0, x, y, width, height);
      }
    }
  }


  function getProjectedTileScreenSize(worldPos, tileWidth, tileHeight) {
    const center = projectWorldToScreen(worldPos.x, WORLD_SURFACE_Y, worldPos.z);
    const east = projectWorldToScreen(worldPos.x + tileWidth, WORLD_SURFACE_Y, worldPos.z);
    const south = projectWorldToScreen(worldPos.x, WORLD_SURFACE_Y, worldPos.z + tileHeight);

    const dx = Math.hypot(east.x - center.x, east.y - center.y);
    const dz = Math.hypot(south.x - center.x, south.y - center.y);

    return Math.max(1, Math.min(dx, dz));
  }

  function drawPlayer(gl, worldPos, tileWidth, tileHeight) {
    const projected = projectWorldToScreen(worldPos.x, WORLD_SURFACE_Y, worldPos.z);
    const screenTileSize = getProjectedTileScreenSize(worldPos, tileWidth, tileHeight);
    const unit = Math.max(1.35, screenTileSize * 0.26);
    const centerX = projected.x;
    const groundY = projected.y;
    const white = [0.93, 0.94, 0.96, 1];
    const mid = [0.82, 0.84, 0.88, 1];
    const dark = [0.58, 0.61, 0.68, 1];
    const shadow = [0.16, 0.24, 0.16, 0.18];
    const softShade = [0.74, 0.76, 0.82, 0.32];
    const outline = [0.34, 0.36, 0.42, 0.50];

    drawEllipse2D(gl, centerX + unit * 0.5, groundY + unit * 0.2, unit * 1.7, unit * 0.58, shadow, 32);
    const pelvisY = groundY - unit * 2.2;
    const waistY = pelvisY - unit * 0.16;
    const abdomenY = pelvisY - unit * 0.68;
    const chestY = pelvisY - unit * 1.34;
    const shoulderY = pelvisY - unit * 1.65;
    const neckY = pelvisY - unit * 1.98;
    const headY = pelvisY - unit * 2.64;
    const leftHipX = centerX - unit * 0.36;
    const rightHipX = centerX + unit * 0.36;
    const kneeY = groundY - unit * 1.08;
    const ankleY = groundY - unit * 0.16;
    const leftKneeX = centerX - unit * 0.42;
    const rightKneeX = centerX + unit * 0.42;
    const leftAnkleX = centerX - unit * 0.32;
    const rightAnkleX = centerX + unit * 0.32;

    drawCapsule2D(gl, leftHipX, pelvisY + unit * 0.1, leftKneeX, kneeY, unit * 0.25, white);
    drawCapsule2D(gl, rightHipX, pelvisY + unit * 0.1, rightKneeX, kneeY, unit * 0.25, white);
    drawCapsule2D(gl, leftKneeX, kneeY, leftAnkleX, ankleY, unit * 0.2, white);
    drawCapsule2D(gl, rightKneeX, kneeY, rightAnkleX, ankleY, unit * 0.2, white);
    drawEllipse2D(gl, leftAnkleX, groundY + unit * 0.03, unit * 0.30, unit * 0.15, mid, 22);
    drawEllipse2D(gl, rightAnkleX, groundY + unit * 0.03, unit * 0.30, unit * 0.15, mid, 22);
    drawEllipse2D(gl, centerX, pelvisY + unit * 0.12, unit * 0.72, unit * 0.32, white, 24);
    drawEllipse2D(gl, centerX, waistY, unit * 0.62, unit * 0.18, mid, 18);
    drawEllipse2D(gl, centerX, abdomenY, unit * 0.78, unit * 0.46, white, 26);
    drawEllipse2D(gl, centerX, chestY, unit * 0.98, unit * 0.78, white, 28);
    drawEllipse2D(gl, centerX, shoulderY - unit * 0.04, unit * 0.72, unit * 0.22, mid, 18);
    drawEllipse2D(gl, centerX - unit * 0.80, shoulderY, unit * 0.30, unit * 0.24, white, 20);
    drawEllipse2D(gl, centerX + unit * 0.80, shoulderY, unit * 0.30, unit * 0.24, white, 20);
    const leftShoulderX = centerX - unit * 0.88;
    const rightShoulderX = centerX + unit * 0.88;
    const elbowY = pelvisY - unit * 0.78;
    const wristY = groundY - unit * 1.24;
    const leftElbowX = centerX - unit * 0.90;
    const rightElbowX = centerX + unit * 0.90;
    const leftWristX = centerX - unit * 0.84;
    const rightWristX = centerX + unit * 0.84;
    drawCapsule2D(gl, leftShoulderX, shoulderY + unit * 0.04, leftElbowX, elbowY, unit * 0.15, white);
    drawCapsule2D(gl, rightShoulderX, shoulderY + unit * 0.04, rightElbowX, elbowY, unit * 0.15, white);
    drawCapsule2D(gl, leftElbowX, elbowY, leftWristX, wristY, unit * 0.12, white);
    drawCapsule2D(gl, rightElbowX, elbowY, rightWristX, wristY, unit * 0.12, white);
    drawEllipse2D(gl, leftWristX, wristY + unit * 0.10, unit * 0.11, unit * 0.15, mid, 16);
    drawEllipse2D(gl, rightWristX, wristY + unit * 0.10, unit * 0.11, unit * 0.15, mid, 16);
    drawEllipse2D(gl, centerX, neckY, unit * 0.18, unit * 0.14, mid, 16);
    drawEllipse2D(gl, centerX, headY, unit * 0.42, unit * 0.58, white, 28);
    drawEllipse2D(gl, centerX + unit * 0.16, headY, unit * 0.10, unit * 0.40, dark, 16);
    drawEllipse2D(gl, centerX + unit * 0.18, chestY + unit * 0.06, unit * 0.16, unit * 0.72, softShade, 16);

    const outlineVertices = [
      centerX - unit * 0.28, headY - unit * 0.46, 0,
      centerX + unit * 0.10, headY - unit * 0.54, 0,
      centerX + unit * 0.40, headY - unit * 0.06, 0,
      centerX + unit * 0.16, headY + unit * 0.46, 0,
      centerX - unit * 0.22, headY + unit * 0.44, 0,
      centerX - unit * 0.42, headY - unit * 0.06, 0
    ];
    useColorProgramScreenSpace(gl);
    gl.bindBuffer(gl.ARRAY_BUFFER, State.render.positionBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(outlineVertices), gl.STREAM_DRAW);
    setCustomColor(gl, outline);
    gl.drawArrays(gl.LINE_LOOP, 0, outlineVertices.length / 3);
  }

  function buildTextureUrl(fileName) {
    const directory = String(Config.TEXTURE_DIRECTORY || "textures").replace(/\\+$/g, "").replace(/\/+$/g, "");
    return `${directory}/${fileName}`;
  }

  function detectImageMimeType(buffer) {
    const bytes = new Uint8Array(buffer || []);
    if (bytes.length >= 8 &&
        bytes[0] === 0x89 && bytes[1] === 0x50 && bytes[2] === 0x4E && bytes[3] === 0x47 &&
        bytes[4] === 0x0D && bytes[5] === 0x0A && bytes[6] === 0x1A && bytes[7] === 0x0A) {
      return "image/png";
    }
    if (bytes.length >= 3 && bytes[0] === 0xFF && bytes[1] === 0xD8 && bytes[2] === 0xFF) {
      return "image/jpeg";
    }
    if (bytes.length >= 12 &&
        bytes[0] === 0x52 && bytes[1] === 0x49 && bytes[2] === 0x46 && bytes[3] === 0x46 &&
        bytes[8] === 0x57 && bytes[9] === 0x45 && bytes[10] === 0x42 && bytes[11] === 0x50) {
      return "image/webp";
    }
    return null;
  }

  function loadImageDirect(url) {
    return new Promise((resolve, reject) => {
      const image = new Image();
      image.onload = () => resolve(image);
      image.onerror = () => reject(new Error(`Failed to decode texture image.`));
      image.src = url;
    });
  }

  function loadImageFromObjectUrl(objectUrl) {
    return new Promise((resolve, reject) => {
      const image = new Image();
      image.onload = () => {
        URL.revokeObjectURL(objectUrl);
        resolve(image);
      };
      image.onerror = () => {
        URL.revokeObjectURL(objectUrl);
        reject(new Error(`Failed to decode texture image.`));
      };
      image.src = objectUrl;
    });
  }

  function canUseDirectTextureLoad(url) {
    try {
      const resolved = new URL(url, window.location.href);
      return resolved.protocol === "file:" || window.location.protocol === "file:";
    } catch (error) {
      return window.location.protocol === "file:";
    }
  }

  function getEmbeddedTextureDataUrl(url) {
    const fileName = String(url || '').split('/').pop();
    const embedded = window.Game.EmbeddedTextures || {};
    return fileName && embedded[fileName] ? embedded[fileName] : null;
  }

  function loadTextureImage(url) {
    const embeddedDataUrl = getEmbeddedTextureDataUrl(url);
    if (embeddedDataUrl) {
      return loadImageDirect(embeddedDataUrl).catch((error) => {
        throw new Error(`Failed to load embedded texture: ${url}${error && error.message ? ` (${error.message})` : ""}`);
      });
    }

    if (canUseDirectTextureLoad(url)) {
      return loadImageDirect(url).catch((error) => {
        throw new Error(`Failed to load texture: ${url}${error && error.message ? ` (${error.message})` : ""}`);
      });
    }

    return fetch(url, { cache: "no-cache" }).then((response) => {
      if (!response.ok) {
        throw new Error(`Failed to load texture: ${url}`);
      }
      return response.arrayBuffer();
    }).then((buffer) => {
      const mimeType = detectImageMimeType(buffer) || "application/octet-stream";
      const blob = new Blob([buffer], { type: mimeType });
      return loadImageFromObjectUrl(URL.createObjectURL(blob));
    }).catch((error) => {
      throw new Error(`Failed to load texture: ${url}${error && error.message ? ` (${error.message})` : ""}`);
    });
  }

  async function ensureTerrainTexturesLoaded() {
    const render = State.render;
    if (render.textureLoadPromise) return render.textureLoadPromise;

    const entries = Object.entries(Config.TEXTURE_FILES || {});
    render.textureLoadStatus = "loading";
    render.textureLoadPromise = Promise.all(entries.map(async ([tileType, fileName]) => {
      const url = buildTextureUrl(fileName);
      const image = await loadTextureImage(url);
      render.textureImages[tileType] = image;
      console.info(`Terrain texture loaded: ${tileType} <- ${url}`);
    })).then(() => {
      render.texturePatterns = {};
      render.textureLoadStatus = "ready";
      markDirty(true, false);
      render.needsBackgroundRebuild = true;
      return render.textureImages;
    }).catch((error) => {
      render.textureLoadStatus = "failed";
      console.warn("Terrain textures could not be loaded.", error);
      throw error;
    });

    return render.textureLoadPromise;
  }

  function getTileTextureImage(tileType) {
    return State.render.textureImages ? State.render.textureImages[tileType] : null;
  }

  function getTileTexturePattern(ctx, tileType) {
    const image = getTileTextureImage(tileType) || getTileTextureImage("grass");
    if (!image) return null;
    const cacheKey = `${tileType}|${canvasWidthCacheKey(ctx.canvas)}|global-rot`;
    const cached = State.render.texturePatterns && State.render.texturePatterns[cacheKey];
    if (cached) return cached;
    const pattern = ctx.createPattern(image, "repeat");
    if (!pattern) return null;
    if (typeof pattern.setTransform === "function" && typeof DOMMatrix !== "undefined") {
      // Rotate the pattern in world space so the sampled texture stays continuous
      // across neighboring tiles instead of restarting tile-by-tile.
      pattern.setTransform(new DOMMatrix().rotate(-45));
    }
    State.render.texturePatterns = State.render.texturePatterns || {};
    State.render.texturePatterns[cacheKey] = pattern;
    return pattern;
  }

  function canvasWidthCacheKey(canvas) {
    return canvas ? `${canvas.width}x${canvas.height}` : 'nocanvas';
  }

  function fillRectWithPattern(ctx, pattern, x, y, width, height) {
    if (!pattern) return;
    ctx.save();
    ctx.beginPath();
    ctx.rect(x, y, width, height);
    ctx.clip();
    ctx.fillStyle = pattern;
    ctx.fillRect(x, y, width, height);
    ctx.restore();
  }

  function buildTexturedBaseCanvas(canvasWidth, canvasHeight, cellWidth, cellHeight) {
    const world = State.world;
    const textureCanvas = document.createElement("canvas");
    textureCanvas.width = canvasWidth;
    textureCanvas.height = canvasHeight;
    const textureCtx = textureCanvas.getContext("2d", { alpha: false });
    if (textureCtx) textureCtx.imageSmoothingEnabled = false;
    if (!textureCtx) return null;

    const generatedShapes = Array.isArray(world && world.generatedTerrainShapes) ? world.generatedTerrainShapes : [];
    const grassPattern = getTileTexturePattern(textureCtx, "grass");
    if (grassPattern) {
      fillRectWithPattern(textureCtx, grassPattern, 0, 0, canvasWidth, canvasHeight);
    } else {
      textureCtx.fillStyle = rgbToCss(rendererFallbackColor("grass"));
      textureCtx.fillRect(0, 0, canvasWidth, canvasHeight);
    }

    if (generatedShapes.length) {
      drawGeneratedTerrainShapeTops(textureCtx, cellWidth, cellHeight, generatedShapes);
    } else {
      for (let row = 0; row < world.rows; row++) {
        for (let col = 0; col < world.cols; col++) {
          const appearance = getVisualTileAppearance(row, col);
          const pattern = getTileTexturePattern(textureCtx, appearance.type);
          const x = Math.floor(col * cellWidth);
          const y = Math.floor(row * cellHeight);
          const width = Math.max(1, Math.ceil((col + 1) * cellWidth) - x);
          const height = Math.max(1, Math.ceil((row + 1) * cellHeight) - y);

          if (pattern) {
            fillRectWithPattern(textureCtx, pattern, x, y, width, height);
          } else {
            const fallbackPattern = getTileTexturePattern(textureCtx, "grass");
            if (fallbackPattern) {
              fillRectWithPattern(textureCtx, fallbackPattern, x, y, width, height);
            } else {
              textureCtx.fillStyle = rgbToCss(appearance.color);
              textureCtx.fillRect(x, y, width, height);
            }
          }
        }
      }
    }

    return textureCanvas;
  }

  // Draw named features (overlays) onto the generated terrain canvas.
  function drawNamedFeatures(ctx, canvasWidth, canvasHeight, cellWidth, cellHeight, onlyAfterProcessing) {
    const world = State.world || {};
    const features = Array.isArray(world.namedFeatures) ? world.namedFeatures : [];
    if (!features.length) return;
    const drawAfter = Boolean(onlyAfterProcessing);

    for (const f of features) {
      try {
        if (!f || f.type !== 'ellipse') continue;
        const isAfter = Boolean(f.afterProcessing);
        if (isAfter !== drawAfter) continue;

        // Determine center in pixel coordinates
        let centerX, centerY;
        if (Number.isFinite(f.centerX) && Number.isFinite(f.centerY)) {
          centerX = f.centerX;
          centerY = f.centerY;
        } else {
          const row = Number.isFinite(f.centerRow) ? f.centerRow : (world.rows / 2 - 0.5);
          const col = Number.isFinite(f.centerCol) ? f.centerCol : (world.cols / 2 - 0.5);
          centerX = (col + 0.5) * cellWidth;
          centerY = (row + 0.5) * cellHeight;
        }

        // Determine radii in pixels
        let rx, ry;
        if (Number.isFinite(f.radiusPxX) && Number.isFinite(f.radiusPxY)) {
          rx = Math.max(1, f.radiusPxX);
          ry = Math.max(1, f.radiusPxY);
        } else {
          const radiusCellsX = Number.isFinite(f.radiusCellsX)
            ? Math.max(1, f.radiusCellsX)
            : Math.max(1, Math.floor(Math.min(world.cols || 1, world.rows || 1) * 0.12));
          const radiusCellsY = Number.isFinite(f.radiusCellsY)
            ? Math.max(1, f.radiusCellsY)
            : radiusCellsX;
          rx = radiusCellsX * cellWidth;
          ry = radiusCellsY * cellHeight;
        }

        const tileTexture = f.texture || 'settlement';
        const pattern = getTileTexturePattern(ctx, tileTexture);
        const tileImage = getTileTextureImage(tileTexture);
        const fillColor = f.fillColor || f.color || null;
        const UI = window.Game && window.Game.UI;
        // (removed TEST ELIPSE debug logging)

        ctx.save();
        ctx.beginPath();
        if (typeof ctx.ellipse === 'function') {
          ctx.ellipse(centerX, centerY, rx, ry, 0, 0, Math.PI * 2);
        } else {
          ctx.save();
          ctx.translate(centerX, centerY);
          ctx.scale(rx, ry);
          ctx.beginPath();
          ctx.arc(0, 0, 1, 0, Math.PI * 2);
          ctx.restore();
        }
        ctx.clip();

        // (removed TEST ELIPSE debug logging)

        // Draw the feature: prefer stretched image only when explicitly requested
        // via `stretchTexture`; do not special-case any named feature here.
        const useStretchedImage = Boolean(f && f.stretchTexture);
        if (useStretchedImage && tileImage) {
          // Draw the tile image scaled to the ellipse bounds; clipping limits it to ellipse shape
          try {
            ctx.drawImage(tileImage, centerX - rx, centerY - ry, rx * 2, ry * 2);
          } catch (e) {
            // drawImage can fail on tainted images; fallback to pattern if available
            if (pattern) {
              ctx.fillStyle = pattern;
              ctx.fillRect(centerX - rx, centerY - ry, rx * 2, ry * 2);
            }
          }

          // Apply color tint on top of the stretched image if requested
          if (fillColor) {
            const prevComposite = ctx.globalCompositeOperation;
            const prevAlpha = ctx.globalAlpha;
            try {
              ctx.globalCompositeOperation = 'source-atop';
              ctx.globalAlpha = Number.isFinite(f.fillAlpha) ? f.fillAlpha : 1.0;
              ctx.fillStyle = fillColor;
              ctx.fillRect(centerX - rx, centerY - ry, rx * 2, ry * 2);
            } finally {
              ctx.globalAlpha = prevAlpha;
              ctx.globalCompositeOperation = prevComposite;
            }
          }
        } else if (pattern) {
          // Fill with the tile pattern first (repeating)
          ctx.fillStyle = pattern;
          ctx.fillRect(centerX - rx, centerY - ry, rx * 2, ry * 2);

          // If a fillColor is present, apply it as a tint over the texture
          if (fillColor) {
            const prevComposite = ctx.globalCompositeOperation;
            const prevAlpha = ctx.globalAlpha;
            try {
              ctx.globalCompositeOperation = 'source-atop';
              const defaultTintAlpha = Number.isFinite(f.fillAlpha) ? f.fillAlpha : 0.6;
              ctx.globalAlpha = defaultTintAlpha;
              ctx.fillStyle = fillColor;
              ctx.fillRect(centerX - rx, centerY - ry, rx * 2, ry * 2);
            } finally {
              ctx.globalAlpha = prevAlpha;
              ctx.globalCompositeOperation = prevComposite;
            }
          }
        } else if (fillColor) {
          // No pattern or image available, fill solid with requested color
          ctx.fillStyle = fillColor;
          ctx.fill();
        } else {
          // Fallback: use a reasonable color based on texture name
          ctx.fillStyle = rgbToCss(rendererFallbackColor(tileTexture)) || '#c9b48d';
          ctx.fill();
        }

        ctx.restore();

        // Draw label if present
        if (f.name) {
          ctx.save();
          const fontSize = Math.max(10, Math.round(Math.min(rx, ry) * 0.16));
          ctx.font = `${fontSize}px sans-serif`;
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.lineWidth = Math.max(2, Math.round(Math.max(1, Math.min(rx, ry) * 0.03)));
          ctx.strokeStyle = 'rgba(0,0,0,0.85)';
          ctx.fillStyle = 'rgba(255,255,255,0.95)';
          ctx.strokeText(f.name, centerX, centerY);
          ctx.fillText(f.name, centerX, centerY);
          ctx.restore();
        }
      } catch (err) {
        console.warn('drawNamedFeatures: failed to draw feature', f, err);
      }
    }
  }

  // Helper to provide a fallback color for a texture name when pattern unavailable.
  function rendererFallbackColor(type) {
    switch (type) {
      case 'grass': return { r: 90, g: 155, b: 95 };
      case 'dirt': return { r: 165, g: 123, b: 78 };
      case 'mountain': return { r: 138, g: 142, b: 150 };
      case 'lake':
      case 'river': return { r: 75, g: 121, b: 180 };
      case 'road': return { r: 185, g: 155, b: 104 };
      case 'forest': return { r: 63, g: 111, b: 69 };
      case 'settlement': return { r: 201, g: 180, b: 141 };
      default: return { r: 90, g: 155, b: 95 };
    }
  }

  // Draw a solid cyan circle at the player's position (200px radius).
  function computePlayerCenterPixel(cellWidth, cellHeight) {
    const world = State.world || {};
    const player = world.player;
    let centerRow = world && world.rows ? (world.rows / 2 - 0.5) : 0;
    let centerCol = world && world.cols ? (world.cols / 2 - 0.5) : 0;
    if (player) {
      if (!player.moving) {
        centerRow = Number.isFinite(player.row) ? player.row : centerRow;
        centerCol = Number.isFinite(player.col) ? player.col : centerCol;
      } else {
        const t = Math.max(0, Math.min(1, player.progress || 0));
        centerRow = player.startRow + (player.targetRow - player.startRow) * t;
        centerCol = player.startCol + (player.targetCol - player.startCol) * t;
      }
    }
    const centerX = (centerCol + 0.5) * cellWidth;
    const centerY = (centerRow + 0.5) * cellHeight;
    return { centerX, centerY };
  }

  // Draw shadow and directional sunlight for a rounded rectangle shape.
  // This draws a cast shadow (offset/blurred) and an inner, sun-facing
  // gradient highlight clipped to the shape interior so only the edge
  // facing the sun receives the light pass.
  function drawTerrainShapeShadowAndLight(ctx, shape, x0, y0, width, height, cornerRadius, cellWidth, cellHeight) {
    try {
      if (!ctx || !shape) return;
      // allow per-shape disable for shadow/light
      if (shape.shadow === false) return;

      const sunAz = degToRad(Number(State.camera.sunAzimuth || 0));
      const sun = { x: Math.cos(sunAz), y: Math.sin(sunAz) };
      const shadowTiles = Math.max(0, Number(State.camera.shadowLength) || 5.4);
      // Shadow offset in pixels (cast opposite to sun direction)
      const offX = -sun.x * shadowTiles * (cellWidth || 1);
      const offY = -sun.y * shadowTiles * (cellHeight || 1);

      const sunElev = Math.max(0, Math.min(90, Number(State.camera.sunElevation || 45)));
      const sunElevFactor = sunElev / 90; // 0..1
      const shadowStrength = clamp01(Number(State.camera.shadowStrength) || 0.34);
      const baseAlpha = Math.max(0.02, shadowStrength * (1 - sunElevFactor * 0.55));

      // blur proportional to shape size and sun elevation
      const blurPx = Math.max(1, Math.round(Math.min(width, height) * 0.04 * (1 - sunElevFactor)));

      // Build a rounded-rect path using Path2D if available
      const path = new Path2D();
      const r = Math.max(0, Math.min(cornerRadius || 0, Math.min(width, height) / 2));
      path.moveTo(x0 + r, y0);
      path.lineTo(x0 + width - r, y0);
      path.arcTo(x0 + width, y0, x0 + width, y0 + r, r);
      path.lineTo(x0 + width, y0 + height - r);
      path.arcTo(x0 + width, y0 + height, x0 + width - r, y0 + height, r);
      path.lineTo(x0 + r, y0 + height);
      path.arcTo(x0, y0 + height, x0, y0 + height - r, r);
      path.lineTo(x0, y0 + r);
      path.arcTo(x0, y0, x0 + r, y0, r);
      path.closePath();

      // --- Shadow pass (unchanged behavior) ---
      ctx.save();
      const hasFilter = typeof ctx.filter === 'string' || typeof ctx.filter === 'function';
      if (hasFilter) {
        try {
          ctx.filter = `blur(${blurPx}px)`;
          ctx.globalAlpha = baseAlpha;
          ctx.fillStyle = '#000';
          ctx.translate(offX, offY);
          ctx.fill(path);
        } finally {
          ctx.filter = 'none';
          ctx.globalAlpha = 1;
        }
      } else {
        // Fallback: draw a few layered fills to fake a soft shadow
        const passes = 4;
        for (let p = passes; p >= 1; p--) {
          const t = p / passes;
          ctx.save();
          ctx.globalAlpha = baseAlpha * (t * 0.35);
          ctx.translate(offX * t * 0.35, offY * t * 0.35);
          ctx.fillStyle = '#000';
          ctx.fill(path);
          ctx.restore();
        }
        ctx.globalAlpha = 1;
      }
      ctx.restore();

      // Inner highlight is drawn after the texture fill so it remains visible.

    } catch (err) {
      console.warn('drawTerrainShapeShadowAndLight failed', err);
    }
  }


  function syncTerrainShapeOverlaySize() {
    const dom = State.dom || {};
    const overlay = dom.terrainShapeOverlay;
    const canvas = dom.canvas;
    if (!overlay || !canvas) return;
    const width = Math.max(1, Math.round(canvas.clientWidth * (window.devicePixelRatio || 1)));
    const height = Math.max(1, Math.round(canvas.clientHeight * (window.devicePixelRatio || 1)));
    if (overlay.width !== width || overlay.height !== height) {
      overlay.width = width;
      overlay.height = height;
    }
  }

  function clearTerrainShapeOverlay() {
    const dom = State.dom || {};
    const ctx = dom.terrainShapeOverlayCtx;
    const overlay = dom.terrainShapeOverlay;
    if (!ctx || !overlay) return;
    syncTerrainShapeOverlaySize();
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.clearRect(0, 0, overlay.width, overlay.height);
  }

  function buildRoundedRectContourPoints(x0, y0, width, height, radius, segmentCount) {
    const points = [];
    const r = Math.max(0, Math.min(radius || 0, Math.min(width, height) / 2));
    const steps = Math.max(3, Number(segmentCount) || 8);

    const addArc = (cx, cy, startAngle, endAngle) => {
      for (let i = 0; i <= steps; i++) {
        const t = i / steps;
        const a = startAngle + (endAngle - startAngle) * t;
        points.push({ x: cx + Math.cos(a) * r, y: cy + Math.sin(a) * r });
      }
    };

    if (r <= EPSILON) {
      points.push(
        { x: x0, y: y0 },
        { x: x0 + width, y: y0 },
        { x: x0 + width, y: y0 + height },
        { x: x0, y: y0 + height }
      );
      return points;
    }

    points.push({ x: x0 + r, y: y0 });
    points.push({ x: x0 + width - r, y: y0 });
    addArc(x0 + width - r, y0 + r, -Math.PI / 2, 0);
    points.push({ x: x0 + width, y: y0 + height - r });
    addArc(x0 + width - r, y0 + height - r, 0, Math.PI / 2);
    points.push({ x: x0 + r, y: y0 + height });
    addArc(x0 + r, y0 + height - r, Math.PI / 2, Math.PI);
    points.push({ x: x0, y: y0 + r });
    addArc(x0 + r, y0 + r, Math.PI, Math.PI * 1.5);

    const deduped = [];
    for (let i = 0; i < points.length; i++) {
      const pt = points[i];
      const prev = deduped[deduped.length - 1];
      if (!prev || Math.hypot(prev.x - pt.x, prev.y - pt.y) > 0.25) deduped.push(pt);
    }
    return deduped;
  }

  function getActiveTerrainShapes() {
    const world = State.world || {};
    if (Array.isArray(world.generatedTerrainShapes) && world.generatedTerrainShapes.length) {
      return world.generatedTerrainShapes;
    }
    return Array.isArray(Config && Config.TERRAIN_SHAPES) ? Config.TERRAIN_SHAPES : [];
  }

  function createRoundedRectPath(ctx, x0, y0, width, height, radius) {
    const r = Math.max(0, Math.min(radius || 0, Math.min(width, height) / 2));
    ctx.beginPath();
    ctx.moveTo(x0 + r, y0);
    ctx.lineTo(x0 + width - r, y0);
    ctx.arcTo(x0 + width, y0, x0 + width, y0 + r, r);
    ctx.lineTo(x0 + width, y0 + height - r);
    ctx.arcTo(x0 + width, y0 + height, x0 + width - r, y0 + height, r);
    ctx.lineTo(x0 + r, y0 + height);
    ctx.arcTo(x0, y0 + height, x0, y0 + height - r, r);
    ctx.lineTo(x0, y0 + r);
    ctx.arcTo(x0, y0, x0 + r, y0, r);
    ctx.closePath();
    return r;
  }

  function drawGeneratedTerrainShapeTops(ctx, cellWidth, cellHeight, shapes) {
    const activeShapes = Array.isArray(shapes) ? shapes : getActiveTerrainShapes();
    if (!ctx || !activeShapes || !activeShapes.length) return;

    const sortedShapes = activeShapes.slice().filter((shape) => shape && shape.visible !== false);
    sortedShapes.sort((a, b) => {
      const ea = Number(a.elevation || 0);
      const eb = Number(b.elevation || 0);
      if (ea !== eb) return ea - eb;
      const aa = (Number(a.widthUnits || 0) || Number(a.width || 0) || 0) * (Number(a.heightUnits || 0) || Number(a.height || 0) || 0);
      const ab = (Number(b.widthUnits || 0) || Number(b.width || 0) || 0) * (Number(b.heightUnits || 0) || Number(b.height || 0) || 0);
      return aa - ab;
    });

    for (const s of sortedShapes) {
      const centerX = Number.isFinite(s.positionX) ? s.positionX * cellWidth : 0;
      const centerY = Number.isFinite(s.positionY) ? s.positionY * cellHeight : 0;
      const width = Number.isFinite(s.widthUnits) ? Math.max(cellWidth, s.widthUnits * cellWidth) : Math.max(1, Number(s.width) || 1);
      const height = Number.isFinite(s.heightUnits) ? Math.max(cellHeight, s.heightUnits * cellHeight) : Math.max(1, Number(s.height) || 1);
      if (width <= 0 || height <= 0) continue;
      const radius = Number.isFinite(s.cornerCurveUnits)
        ? Math.max(0, s.cornerCurveUnits * Math.min(cellWidth, cellHeight))
        : Math.max(0, Number(s.cornerCurve) || 0);
      const x0 = centerX - width * 0.5;
      const y0 = centerY - height * 0.5;
      const textureKey = typeof s.texture === 'string' && s.texture ? s.texture : 'grass';
      const pattern = getTileTexturePattern(ctx, textureKey) || getTileTexturePattern(ctx, 'grass');

      try {
        drawTerrainShapeShadowAndLight(ctx, s, x0, y0, width, height, radius, cellWidth, cellHeight);
      } catch (err) {
        console.warn('drawTerrainShapeShadowAndLight failed', err);
      }

      ctx.save();
      createRoundedRectPath(ctx, x0, y0, width, height, radius);
      ctx.clip();
      if (pattern) {
        ctx.fillStyle = pattern;
        ctx.fillRect(x0, y0, width, height);
      } else {
        ctx.fillStyle = rgbToCss(rendererFallbackColor(textureKey));
        ctx.fillRect(x0, y0, width, height);
      }
      ctx.restore();

      try {
        drawTerrainShapeInnerLight(ctx, s, x0, y0, width, height, radius, cellWidth, cellHeight);
      } catch (err) {
        console.warn('drawTerrainShapeInnerLight failed', err);
      }
    }
  }

  function getTerrainShapeLogicalGeometry(shape) {
    const world = State.world || {};
    const metrics = getGridMetrics();
    const bg = State.render && State.render.worldBackgroundCanvas;
    const bgCellWidth = bg ? bg.width / Math.max(1, world.cols || 1) : metrics.tileWidth;
    const bgCellHeight = bg ? bg.height / Math.max(1, world.rows || 1) : metrics.tileHeight;

    const centerX = Number.isFinite(shape.positionX)
      ? Math.max(0, Math.min(Math.max(1, world.cols || 1), shape.positionX)) * metrics.tileWidth
      : ((world.player && world.player.col != null ? world.player.col + 0.5 : (world.cols || 1) * 0.5) * metrics.tileWidth);
    const centerZ = Number.isFinite(shape.positionY)
      ? Math.max(0, Math.min(Math.max(1, world.rows || 1), shape.positionY)) * metrics.tileHeight
      : ((world.player && world.player.row != null ? world.player.row + 0.5 : (world.rows || 1) * 0.5) * metrics.tileHeight);

    const widthWorld = Number.isFinite(shape.widthUnits)
      ? Math.max(metrics.tileWidth, Number(shape.widthUnits) * metrics.tileWidth)
      : (Math.max(1, Number(shape.width) || 400) / Math.max(EPSILON, bgCellWidth)) * metrics.tileWidth;
    const heightWorld = Number.isFinite(shape.heightUnits)
      ? Math.max(metrics.tileHeight, Number(shape.heightUnits) * metrics.tileHeight)
      : (Math.max(1, Number(shape.height) || 400) / Math.max(EPSILON, bgCellHeight)) * metrics.tileHeight;
    const radiusWorld = Number.isFinite(shape.cornerCurveUnits)
      ? Math.max(0, Number(shape.cornerCurveUnits) * Math.min(metrics.tileWidth, metrics.tileHeight))
      : (Math.max(0, Number(shape.cornerCurve) || 0) / Math.max(EPSILON, Math.min(bgCellWidth, bgCellHeight))) * Math.min(metrics.tileWidth, metrics.tileHeight);

    return {
      centerX,
      centerZ,
      widthWorld,
      heightWorld,
      radiusWorld,
      x0: centerX - widthWorld * 0.5,
      z0: centerZ - heightWorld * 0.5
    };
  }


  function getProjectedLowerContourChain(projected) {
    if (!Array.isArray(projected) || projected.length < 3) return [];

    let leftIndex = 0;
    let rightIndex = 0;
    for (let i = 1; i < projected.length; i++) {
      const pt = projected[i];
      if (!pt) continue;
      const leftPt = projected[leftIndex];
      const rightPt = projected[rightIndex];
      if (!leftPt || pt.x < leftPt.x || (Math.abs(pt.x - leftPt.x) < 0.001 && pt.y > leftPt.y)) leftIndex = i;
      if (!rightPt || pt.x > rightPt.x || (Math.abs(pt.x - rightPt.x) < 0.001 && pt.y > rightPt.y)) rightIndex = i;
    }

    const buildChain = (start, end, step) => {
      const pts = [];
      const n = projected.length;
      let idx = start;
      let guard = 0;
      while (guard++ <= n + 1) {
        pts.push(projected[idx]);
        if (idx === end) break;
        idx = (idx + step + n) % n;
      }
      return pts;
    };

    const chainA = buildChain(leftIndex, rightIndex, 1);
    const chainB = buildChain(leftIndex, rightIndex, -1);

    const scoreChain = (chain) => {
      let score = 0;
      let weight = 0;
      for (let i = 0; i < chain.length - 1; i++) {
        const a = chain[i];
        const b = chain[i + 1];
        if (!a || !b) continue;
        const len = Math.hypot(b.x - a.x, b.y - a.y);
        if (len < 0.001) continue;
        score += ((a.y + b.y) * 0.5) * len;
        weight += len;
      }
      return weight > 0 ? score / weight : -Infinity;
    };

    return scoreChain(chainA) >= scoreChain(chainB) ? chainA : chainB;
  }

  function createGameplayDiamondClipPath(ctx) {
    const world = State.world || {};
    const cols = Math.max(1, Number(world.cols) || 1);
    const rows = Math.max(1, Number(world.rows) || 1);
    const metrics = getGridMetrics();
    const corners = [
      projectWorldToScreen(0, WORLD_SURFACE_Y, 0),
      projectWorldToScreen(cols * metrics.tileWidth, WORLD_SURFACE_Y, 0),
      projectWorldToScreen(cols * metrics.tileWidth, WORLD_SURFACE_Y, rows * metrics.tileHeight),
      projectWorldToScreen(0, WORLD_SURFACE_Y, rows * metrics.tileHeight)
    ].filter(Boolean);
    if (corners.length < 3) return false;
    ctx.beginPath();
    ctx.moveTo(corners[0].x, corners[0].y);
    for (let i = 1; i < corners.length; i++) ctx.lineTo(corners[i].x, corners[i].y);
    ctx.closePath();
    return true;
  }

  function drawTerrainShape2p5dOverlay() {
    const dom = State.dom || {};
    const ctx = dom.terrainShapeOverlayCtx;
    const overlay = dom.terrainShapeOverlay;
    const shapes = getActiveTerrainShapes();
    if (!ctx || !overlay) return;

    syncTerrainShapeOverlaySize();
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.clearRect(0, 0, overlay.width, overlay.height);

    if (!Config || !Config.DEFAULT_SHOW_TERRAIN_SHAPE || !shapes.length) return;
    if (State.camera && State.camera.showTerrainWalls === false) return;

    const dpr = Math.max(1, window.devicePixelRatio || 1);
    ctx.save();
    ctx.scale(dpr, dpr);
    if (createGameplayDiamondClipPath(ctx)) ctx.clip();

    const wallSegments = [];

    for (let i = 0; i < shapes.length; i++) {
      const shape = shapes[i] || {};
      if (shape.visible === false) continue;

      const geom = getTerrainShapeLogicalGeometry(shape);
      const contour = buildRoundedRectContourPoints(geom.x0, geom.z0, geom.widthWorld, geom.heightWorld, geom.radiusWorld, 10);
      if (contour.length < 3) continue;

      const projected = contour.map((pt) => projectWorldToScreen(pt.x, WORLD_SURFACE_Y, pt.y));
      if (!projected.some((pt) => pt && pt.visible)) continue;

      let minY = Infinity;
      let maxY = -Infinity;
      for (const pt of projected) {
        if (pt.y < minY) minY = pt.y;
        if (pt.y > maxY) maxY = pt.y;
      }
      const lowerChain = getProjectedLowerContourChain(projected);
      if (lowerChain.length < 2) continue;

      const generatedShapeMode = Array.isArray((State.world || {}).generatedTerrainShapes) && (State.world || {}).generatedTerrainShapes.length > 0;
      const elevation = Number(shape.elevation || 0);
      if (generatedShapeMode && elevation <= 1) continue;
      const elevationDelta = generatedShapeMode ? Math.max(0, elevation - 1) : 1;
      const sideDepth = Math.max(5, Math.min(24, (maxY - minY) * 0.07 * Math.max(1, elevationDelta)));
      const textureKey = typeof shape.texture === 'string' && shape.texture ? shape.texture : 'settlement';
      const textureImage = getTileTextureImage(textureKey) || getTileTextureImage('grass');
      const shapeDepthKey = lowerChain.reduce((sum, pt) => sum + (pt ? pt.y : 0), 0) / Math.max(1, lowerChain.length);

      for (let p = 0; p < lowerChain.length - 1; p++) {
        const a = lowerChain[p];
        const b = lowerChain[p + 1];
        if (!a || !b) continue;

        const dx = b.x - a.x;
        const dy = b.y - a.y;
        const segLen = Math.hypot(dx, dy);
        if (segLen < 1.5) continue;
        const maxReasonableSegLen = Math.max(32, Math.max(overlay.width, overlay.height) * 0.35);
        if (segLen > maxReasonableSegLen) continue;

        const a2 = { x: a.x, y: a.y + sideDepth };
        const b2 = { x: b.x, y: b.y + sideDepth };
        const avgY = (a.y + b.y + a2.y + b2.y) * 0.25;

        wallSegments.push({
          a, b, a2, b2, dx, dy, sideDepth, textureImage,
          sortKey: avgY,
          shapeDepthKey,
          shapeIndex: i
        });
      }
    }

    wallSegments.sort((lhs, rhs) => {
      if (Math.abs(lhs.sortKey - rhs.sortKey) > 0.01) return lhs.sortKey - rhs.sortKey;
      if (Math.abs(lhs.shapeDepthKey - rhs.shapeDepthKey) > 0.01) return lhs.shapeDepthKey - rhs.shapeDepthKey;
      return lhs.shapeIndex - rhs.shapeIndex;
    });

    for (let i = 0; i < wallSegments.length; i++) {
      const seg = wallSegments[i];
      const { a, b, a2, b2, dx, dy, sideDepth, textureImage } = seg;

      ctx.save();
      ctx.beginPath();
      ctx.moveTo(a.x, a.y);
      ctx.lineTo(b.x, b.y);
      ctx.lineTo(b2.x, b2.y);
      ctx.lineTo(a2.x, a2.y);
      ctx.closePath();
      ctx.clip();

      if (textureImage) {
        const pat = ctx.createPattern(textureImage, 'repeat');
        if (pat) {
          if (typeof pat.setTransform === 'function' && typeof DOMMatrix !== 'undefined') {
            const texW = Math.max(1, textureImage.width || 256);
            const texH = Math.max(1, textureImage.height || 256);
            const matrix = new DOMMatrix([dx / texW, dy / texW, 0, Math.max(0.35, sideDepth / texH), a.x, a.y]);
            pat.setTransform(matrix);
          }
          ctx.fillStyle = pat;
          const minX = Math.min(a.x, b.x, a2.x, b2.x) - 4;
          const minYq = Math.min(a.y, b.y, a2.y, b2.y) - 4;
          const maxX = Math.max(a.x, b.x, a2.x, b2.x) + 4;
          const maxYq = Math.max(a.y, b.y, a2.y, b2.y) + 4;
          ctx.fillRect(minX, minYq, maxX - minX, maxYq - minYq);
        }
      }

      const grad = ctx.createLinearGradient(0, a.y, 0, a2.y);
      grad.addColorStop(0, 'rgba(255,255,255,0.06)');
      grad.addColorStop(0.08, 'rgba(0,0,0,0.05)');
      grad.addColorStop(0.55, 'rgba(0,0,0,0.20)');
      grad.addColorStop(1, 'rgba(0,0,0,0.34)');
      ctx.fillStyle = grad;
      ctx.fillRect(
        Math.min(a.x, b.x, a2.x, b2.x) - 4,
        Math.min(a.y, b.y, a2.y, b2.y) - 4,
        Math.max(a.x, b.x, a2.x, b2.x) - Math.min(a.x, b.x, a2.x, b2.x) + 8,
        Math.max(a.y, b.y, a2.y, b2.y) - Math.min(a.y, b.y, a2.y, b2.y) + 8
      );

      ctx.restore();

      ctx.save();
      ctx.beginPath();
      ctx.moveTo(a.x, a.y);
      ctx.lineTo(a2.x, a2.y);
      ctx.moveTo(b.x, b.y);
      ctx.lineTo(b2.x, b2.y);
      ctx.strokeStyle = 'rgba(0,0,0,0.16)';
      ctx.lineWidth = Math.max(1, sideDepth * 0.018);
      ctx.stroke();
      ctx.restore();
    }

    ctx.restore();
  }

  function drawTerrainShape(ctx, canvasWidth, canvasHeight, cellWidth, cellHeight) {
    if (!ctx) return;
    // Global visibility flag
    if (!Config || !Config.DEFAULT_SHOW_TERRAIN_SHAPE) {
      // Debug: log when shapes are disabled globally
      try { if (console && console.info) console.info('drawTerrainShape: disabled by DEFAULT_SHOW_TERRAIN_SHAPE flag'); } catch (e) {}
      return;
    }
    const world = State.world || {};
    if (!world) {
      try { if (console && console.info) console.info('drawTerrainShape: no world available'); } catch (e) {}
      return;
    }

    const shapes = getActiveTerrainShapes();
    if (Array.isArray((State.world || {}).generatedTerrainShapes) && (State.world || {}).generatedTerrainShapes.length) return;
    try { if (console && console.info) console.info(`drawTerrainShape: configured shapes=${shapes.length}`); } catch (e) {}
    if (!shapes.length) {
      try { if (console && console.info) console.info('drawTerrainShape: no TERRAIN_SHAPES configured'); } catch (e) {}
      return;
    }

    // Precompute player center as fallback
    const playerCenter = computePlayerCenterPixel(cellWidth, cellHeight);

    for (let i = 0; i < shapes.length; i++) {
      const s = shapes[i] || {};
      if (s.visible === false) continue;

      // Determine center pixel coordinates.
      // Interpret `positionX`/`positionY` as tile coordinates (in tile units)
      // and convert to pixel positions on the background canvas. If a value
      // is not provided, fall back to the player's center pixel.
      let centerX = NaN;
      let centerY = NaN;
      if (Number.isFinite(s.positionX)) {
        const maxCols = Math.max(1, (State.world && State.world.cols) || 80);
        const tx = Math.max(0, Math.min(maxCols, s.positionX));
        centerX = tx * cellWidth;
      }
      if (Number.isFinite(s.positionY)) {
        const maxRows = Math.max(1, (State.world && State.world.rows) || 80);
        const ty = Math.max(0, Math.min(maxRows, s.positionY));
        centerY = ty * cellHeight;
      }
      if (!Number.isFinite(centerX)) centerX = playerCenter.centerX;
      if (!Number.isFinite(centerY)) centerY = playerCenter.centerY;

      const width = Number.isFinite(s.width) ? Math.max(1, s.width) : 400;
      const height = Number.isFinite(s.height) ? Math.max(1, s.height) : 400;
      const corner = Number.isFinite(s.cornerCurve) ? Math.max(0, s.cornerCurve) : 24;

      const x0 = centerX - width / 2;
      const y0 = centerY - height / 2;
      const r = Math.max(0, Math.min(corner, Math.min(width, height) / 2));

      // Draw cast shadow and edge light for this shape before filling
      // the shape itself.
      try {
        drawTerrainShapeShadowAndLight(ctx, s, x0, y0, width, height, r, cellWidth, cellHeight);
      } catch (err) {
        console.warn('drawTerrainShapeShadowAndLight failed', err);
      }

      ctx.save();
      ctx.beginPath();
      ctx.moveTo(x0 + r, y0);
      ctx.lineTo(x0 + width - r, y0);
      ctx.arcTo(x0 + width, y0, x0 + width, y0 + r, r);
      ctx.lineTo(x0 + width, y0 + height - r);
      ctx.arcTo(x0 + width, y0 + height, x0 + width - r, y0 + height, r);
      ctx.lineTo(x0 + r, y0 + height);
      ctx.arcTo(x0, y0 + height, x0, y0 + height - r, r);
      ctx.lineTo(x0, y0 + r);
      ctx.arcTo(x0, y0, x0 + r, y0, r);
      ctx.closePath();

      const prevAlpha = ctx.globalAlpha;
      try {
        ctx.globalAlpha = 1.0;
        const textureKey = typeof s.texture === 'string' && s.texture ? s.texture : 'settlement';
        const pattern = getTileTexturePattern(ctx, textureKey);
        if (pattern) {
          ctx.save();
          ctx.clip();
          ctx.fillStyle = pattern;
          ctx.fillRect(x0, y0, width, height);
          ctx.restore();
        } else {
          ctx.fillStyle = '#00FFFF';
          ctx.fill();
        }
      } finally {
        ctx.globalAlpha = prevAlpha;
      }

      // Draw inner highlight on top of the painted texture so it remains visible
      try {
        drawTerrainShapeInnerLight(ctx, s, x0, y0, width, height, r, cellWidth, cellHeight);
      } catch (err) {
        console.warn('drawTerrainShapeInnerLight failed', err);
      }

      // Terrain-shape lighting is handled by drawTerrainShapeShadowAndLight
      // (inner highlight is applied there). Do not call tile-based
      // lighting helpers here — shape lighting is independent.

      // Draw label for this shape
      try {
        ctx.save();
        const fontSize = Math.max(10, Math.round(Math.min(width, height) * 0.16));
        ctx.font = `${fontSize}px sans-serif`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.lineWidth = Math.max(2, Math.round(Math.max(1, Math.min(width, height) * 0.03)));
        ctx.strokeStyle = 'rgba(0,0,0,0.85)';
        ctx.fillStyle = 'rgba(255,255,255,0.95)';
        const label = typeof s.label === 'string' && s.label ? s.label : 'TERRAIN_SHAPE';
        ctx.strokeText(label, centerX, centerY);
        ctx.fillText(label, centerX, centerY);
        ctx.restore();
      } catch (e) {
        // ignore
      }

      ctx.restore();
    }
  }

  // Elevation overlays disabled.
  function applyElevationOverlays(/* ctx, cellWidth, cellHeight */) {
    // No-op to keep compatibility; elevation overlays disabled.
    return;
  }

  function getTextureSample(basePixels, canvasWidth, canvasHeight, x, y) {
    if (!basePixels || !basePixels.length) return null;
    const sx = Math.max(0, Math.min(canvasWidth - 1, Math.round(x)));
    const sy = Math.max(0, Math.min(canvasHeight - 1, Math.round(y)));
    const idx = (sy * canvasWidth + sx) * 4;
    return {
      r: basePixels[idx],
      g: basePixels[idx + 1],
      b: basePixels[idx + 2]
    };
  }

  function buildTexturedBlendColor(seed, rowFloat, colFloat, basePixels, canvasWidth, canvasHeight, sampleX, sampleY) {
    const blendColor = buildBlendColor(seed, rowFloat, colFloat);
    const textureColor = getTextureSample(basePixels, canvasWidth, canvasHeight, sampleX, sampleY);
    if (!textureColor) return blendColor;
    return mixRgb(textureColor, blendColor, Config.DEFAULT_TEXTURE_TINT_STRENGTH || 0.38);
  }

  function getBackgroundResolution(cols, rows) {
    const render = State.render || {};
    const gl = render.gl;
    const gpuMax = gl ? Number(gl.getParameter(gl.MAX_TEXTURE_SIZE) || 4096) : 4096;
    const maxSize = Math.max(2048, Math.min(gpuMax, 8192));
    const safeCols = Math.max(1, cols || 1);
    const safeRows = Math.max(1, rows || 1);
    const targetPxPerCell = Math.max(64, Number(Config.BACKGROUND_PIXELS_PER_CELL || 128));
    const scale = Math.min(1, maxSize / Math.max(safeCols * targetPxPerCell, safeRows * targetPxPerCell));
    const pxPerCell = Math.max(64, Math.floor(targetPxPerCell ));
    return {
      width: Math.max(1, Math.min(maxSize, safeCols * pxPerCell)),
      height: Math.max(1, Math.min(maxSize, safeRows * pxPerCell))
    };
  }

  function applyPostTileNoiseCanvas(/* ctx, canvasWidth, canvasHeight, cellWidth, cellHeight, seed */) {
    // Disabled: terrain is now rendered through terrain shapes and the previous
    // per-tile color noise pass caused visible flicker/artifacts along wall edges.
    return;
  }

  function redrawElevatedTerrainOverRoadsFromCanvas(ctx, sourceCanvas, cellWidth, cellHeight) {
    const world = State.world;
    const roadLevel = 1;
    if (!sourceCanvas) return;

    for (let row = 0; row < world.rows; row++) {
      for (let col = 0; col < world.cols; col++) {
        const tile = getTile(row, col);
        if (!tile) continue;
        if (isRoadClearanceTile(row, col)) continue;
        if (getRenderLevel(tile, row, col) <= roadLevel) continue;

        const x = Math.floor(col * cellWidth);
        const y = Math.floor(row * cellHeight);
        const width = Math.max(1, Math.ceil((col + 1) * cellWidth) - x);
        const height = Math.max(1, Math.ceil((row + 1) * cellHeight) - y);
        ctx.drawImage(sourceCanvas, x, y, width, height, x, y, width, height);
      }
    }
  }

  function rebuildBackgroundCanvas() {
    const world = State.world;
    const render = State.render;
    const UI = window.Game && window.Game.UI;
    if (render && render.preserveBackground) {
      if (UI && UI.addLog) UI.addLog('Background rebuild aborted: preserving imported map image.', `Source: ${render.backgroundSource || 'imported'}`);
      return;
    }
    if (!world || !world.terrain || !world.terrain.length) return;

    render.roadAppearanceCache = new Map();

    const resolution = getBackgroundResolution(world.cols, world.rows);
    const canvas = document.createElement("canvas");
    canvas.width = resolution.width;
    canvas.height = resolution.height;
    render.worldBackgroundCanvas = canvas;

    const ctx = canvas.getContext("2d", { alpha: false });
    if (ctx) ctx.imageSmoothingEnabled = false;
    if (!ctx) return;

    const blockSize = Math.max(1, Math.round(State.camera.blendPixelSize || 4));
    const cellWidth = canvas.width / Math.max(1, world.cols);
    const cellHeight = canvas.height / Math.max(1, world.rows);
    render.backgroundSource = 'generated-texture';
    const seed = `${world.seed}|blend|${blockSize}|${State.camera.blendStrength || 0}`;
    const texturedBaseCanvas = buildTexturedBaseCanvas(canvas.width, canvas.height, cellWidth, cellHeight);
    const pxPerCell = (canvas.width / Math.max(1, world.cols)).toFixed(1);
    console.info(`Background rebuild started (${canvas.width}x${canvas.height}), px/cell=${pxPerCell}.`);
    console.info('Terrain pipeline: textures -> roads.');
    if (UI && UI.addLog) {
      UI.addLog(`Terrain rebuild: textures base ${canvas.width}x${canvas.height}, ${pxPerCell}px/cell.`);
      UI.addLog('Terrain post-process: direct textures + roads.');
    }

    if (texturedBaseCanvas) {
      ctx.drawImage(texturedBaseCanvas, 0, 0);
      // Draw named features (overlays) onto base texture (e.g., non-afterProcessing features)
      try {
        drawNamedFeatures(ctx, canvas.width, canvas.height, cellWidth, cellHeight, false);
      } catch (e) {
        console.warn('drawNamedFeatures failed', e);
      }
      // Apply elevation overlays (slopes) before tint/shadow passes
      try {
        applyElevationOverlays(ctx, cellWidth, cellHeight);
      } catch (e) {
        console.warn('applyElevationOverlays failed', e);
      }
    } else {
      ctx.fillStyle = "#000";
      ctx.fillRect(0, 0, canvas.width, canvas.height);
    }

    // Tile blend/tint and post-texture color noise are disabled.
    // The terrain is now shape-driven, so raw terrain textures should remain stable.

    const preRoadCanvas = document.createElement("canvas");
    preRoadCanvas.width = canvas.width;
    preRoadCanvas.height = canvas.height;
    const preRoadCtx = preRoadCanvas.getContext("2d", { alpha: false });
    if (preRoadCtx) {
      preRoadCtx.drawImage(canvas, 0, 0);
    }

    drawRoadOverlay(ctx, cellWidth, cellHeight);
    redrawElevatedTerrainOverRoadsFromCanvas(ctx, preRoadCanvas, cellWidth, cellHeight);
    // Draw named features that must appear after all painting steps (e.g., TEST ELIPSE)
    try {
      drawNamedFeatures(ctx, canvas.width, canvas.height, cellWidth, cellHeight, true);
    } catch (e) {
      console.warn('drawNamedFeatures (after) failed', e);
    }
    // Draw the terrain overlay shape after all terrain painting finished
    try {
      drawTerrainShape(ctx, canvas.width, canvas.height, cellWidth, cellHeight);
    } catch (e) {
      console.warn('drawTerrainShape failed', e);
    }
    render.needsBackgroundRebuild = false;
    render.needsBackgroundUpload = true;
    console.info(`Background rebuild finished (${canvas.width}x${canvas.height}).`);
    if (UI && UI.addLog) {
      UI.addLog(`Terrain rebuild finished: roads layered, background ready.`, `Background source: ${render.backgroundSource || 'generated'}.`);
    }
  }

  function scaleCanvasToMaxTextureSize(sourceCanvas, maxTextureSize) {
    if (!sourceCanvas) return null;
    const width = Math.max(1, Number(sourceCanvas.width) || 1);
    const height = Math.max(1, Number(sourceCanvas.height) || 1);
    const limit = Math.max(256, Number(maxTextureSize) || 4096);
    const largestSide = Math.max(width, height);
    if (largestSide <= limit) return sourceCanvas;

    const scale = limit / largestSide;
    const nextWidth = Math.max(1, Math.floor(width ));
    const nextHeight = Math.max(1, Math.floor(height ));
    const canvas = document.createElement("canvas");
    canvas.width = nextWidth;
    canvas.height = nextHeight;
    const ctx = canvas.getContext("2d", { alpha: false });
    if (!ctx) return sourceCanvas;
    ctx.imageSmoothingEnabled = true;
    ctx.drawImage(sourceCanvas, 0, 0, nextWidth, nextHeight);
    return canvas;
  }

  function ensureBackgroundTexture(gl) {
    const render = State.render;
    const UI = window.Game && window.Game.UI;
    const maxTextureSize = Number(gl.getParameter(gl.MAX_TEXTURE_SIZE) || 4096) || 4096;
    if (render.backgroundUploadBlocked && !render.needsBackgroundUpload && !render.backgroundTextureReady) {
      return false;
    }
    if (render.needsBackgroundRebuild && render.preserveBackground) {
      if (UI && UI.addLog) UI.addLog('Background rebuild suppressed to preserve imported map image.', `Source: ${render.backgroundSource || 'imported'}`);
      // If a preserved background canvas exists, draw named overlays (e.g., TEST ELIPSE)
      // directly onto the preserved canvas so overlays are visible without a full rebuild.
      try {
        if (render.worldBackgroundCanvas && typeof drawNamedFeatures === 'function') {
          const canvas = render.worldBackgroundCanvas;
          const ctx2d = canvas.getContext('2d', { alpha: false });
          if (ctx2d) {
            ctx2d.imageSmoothingEnabled = false;
            const cellWidth = canvas.width / Math.max(1, (State.world && State.world.cols) || 1);
            const cellHeight = canvas.height / Math.max(1, (State.world && State.world.rows) || 1);
            try {
              drawNamedFeatures(ctx2d, canvas.width, canvas.height, cellWidth, cellHeight, false);
            } catch (err) {
              console.warn('drawNamedFeatures (pre) failed on preserved background', err);
            }
            try {
              drawNamedFeatures(ctx2d, canvas.width, canvas.height, cellWidth, cellHeight, true);
            } catch (err) {
              console.warn('drawNamedFeatures (after) failed on preserved background', err);
            }
            // Draw the player circle overlay onto preserved background as well
            try {
              drawTerrainShape(ctx2d, canvas.width, canvas.height, cellWidth, cellHeight);
            } catch (err) {
              console.warn('drawTerrainShape failed on preserved background', err);
            }
            // Flag that the background needs uploading to the GL texture
            render.needsBackgroundUpload = true;
            render.backgroundTextureReady = false;
          }
        }
      } catch (e) {
        console.warn('Failed to draw named features onto preserved background', e);
      }
      render.needsBackgroundRebuild = false;
    }
    if (render.needsBackgroundRebuild || !render.worldBackgroundCanvas) rebuildBackgroundCanvas();
    if (!render.worldBackgroundCanvas) return false;
    if (!render.needsBackgroundUpload && render.backgroundTextureReady) return true;

    gl.bindTexture(gl.TEXTURE_2D, render.backgroundTexture);
    gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, true);
    try {
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, render.worldBackgroundCanvas);
      render.backgroundUploadBlocked = false;
      if (UI && UI.addLog) UI.addLog(`Background texture uploaded from ${render.backgroundSource || 'generated'}.`, `${render.worldBackgroundCanvas.width}x${render.worldBackgroundCanvas.height}`);
    } catch (error) {
      console.warn("Background texture upload failed.", error);
      const errorMessage = error && error.message ? error.message : String(error);
      const taintedCanvasError = /tainted canvases may not be loaded/i.test(errorMessage);
      if (UI && UI.addLog) {
        UI.addLog(
          'Background texture upload failed.',
          `Source: ${render.backgroundSource || 'unknown'}. Canvas: ${render.worldBackgroundCanvas ? `${render.worldBackgroundCanvas.width}x${render.worldBackgroundCanvas.height}` : 'none'}. MAX_TEXTURE_SIZE: ${maxTextureSize}. Error: ${errorMessage}`
        );
      }

      if (taintedCanvasError) {
        if (render.preserveBackground) {
          if (UI && UI.addLog) {
            UI.addLog(
              'Imported map image cannot be used as quad texture in this browser context.',
              'Browser security marked the imported canvas as tainted. Falling back to generated terrain background.'
            );
          }
          render.preserveBackground = false;
          render.backgroundUploadBlocked = false;
          render.needsBackgroundRebuild = true;
          render.needsBackgroundUpload = true;
          render.backgroundTextureReady = false;
          rebuildBackgroundCanvas();
          if (!render.worldBackgroundCanvas) {
            render.backgroundUploadBlocked = true;
            render.needsBackgroundUpload = false;
            return false;
          }
          try {
            gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, render.worldBackgroundCanvas);
            render.backgroundUploadBlocked = false;
            if (UI && UI.addLog) UI.addLog(`Background texture uploaded from ${render.backgroundSource || 'generated'} (security fallback).`, `${render.worldBackgroundCanvas.width}x${render.worldBackgroundCanvas.height}`);
            render.needsBackgroundUpload = false;
            render.backgroundTextureReady = true;
            return true;
          } catch (securityFallbackError) {
            if (UI && UI.addLog) {
              UI.addLog(
                'Fallback background upload also failed.',
                securityFallbackError && securityFallbackError.message ? securityFallbackError.message : String(securityFallbackError)
              );
            }
            render.backgroundUploadBlocked = true;
            render.needsBackgroundUpload = false;
            return false;
          }
        }

        render.backgroundUploadBlocked = true;
        render.needsBackgroundUpload = false;
        return false;
      }

      if (render.worldBackgroundCanvas) {
        const fittedCanvas = scaleCanvasToMaxTextureSize(render.worldBackgroundCanvas, maxTextureSize);
        if (fittedCanvas && fittedCanvas !== render.worldBackgroundCanvas) {
          render.worldBackgroundCanvas = fittedCanvas;
          render.needsBackgroundRebuild = false;
          render.needsBackgroundUpload = true;
          render.backgroundTextureReady = false;
          if (UI && UI.addLog) {
            UI.addLog(
              'Background canvas downscaled for GPU limits.',
              `New canvas: ${fittedCanvas.width}x${fittedCanvas.height} (MAX_TEXTURE_SIZE=${maxTextureSize}).`
            );
          }
          try {
            gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, render.worldBackgroundCanvas);
            render.backgroundUploadBlocked = false;
            if (UI && UI.addLog) UI.addLog(`Background texture uploaded from ${render.backgroundSource || 'generated'} (downscaled).`, `${render.worldBackgroundCanvas.width}x${render.worldBackgroundCanvas.height}`);
            render.needsBackgroundUpload = false;
            render.backgroundTextureReady = true;
            return true;
          } catch (downscaleError) {
            if (UI && UI.addLog) {
              UI.addLog(
                'Background upload failed after downscaling.',
                downscaleError && downscaleError.message ? downscaleError.message : String(downscaleError)
              );
            }
          }
        }
      }

      render.needsBackgroundRebuild = true;
      render.needsBackgroundUpload = true;
      render.backgroundTextureReady = false;
      rebuildBackgroundCanvas();
      if (!render.worldBackgroundCanvas) return false;
      try {
        gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, render.worldBackgroundCanvas);
        render.backgroundUploadBlocked = false;
        if (UI && UI.addLog) UI.addLog(`Background texture uploaded from ${render.backgroundSource || 'generated'} (retry).`, `${render.worldBackgroundCanvas.width}x${render.worldBackgroundCanvas.height}`);
      } catch (retryError) {
        console.warn("Background texture upload retry failed.", retryError);
        render.backgroundUploadBlocked = true;
        render.needsBackgroundUpload = false;
        return false;
      }
    }

    render.needsBackgroundUpload = false;
    render.backgroundTextureReady = true;
    return true;
  }

  function drawBackgroundQuad(gl, metrics) {
    if (!ensureBackgroundTexture(gl)) return;

    const render = State.render;
    const world = State.world;
    const width = world.cols * metrics.tileWidth;
    const depth = world.rows * metrics.tileHeight;

    const c00 = logicalToRenderXZ(0, 0);
    const c10 = logicalToRenderXZ(width, 0);
    const c01 = logicalToRenderXZ(0, depth);
    const c11 = logicalToRenderXZ(width, depth);

    const positions = [
      c00.x, WORLD_SURFACE_Y, c00.z,
      c10.x, WORLD_SURFACE_Y, c10.z,
      c01.x, WORLD_SURFACE_Y, c01.z,
      c01.x, WORLD_SURFACE_Y, c01.z,
      c10.x, WORLD_SURFACE_Y, c10.z,
      c11.x, WORLD_SURFACE_Y, c11.z
    ];

    const texCoords = [
      0, 1,
      1, 1,
      0, 0,
      0, 0,
      1, 1,
      1, 0
    ];

    useTextureProgram(gl);
    gl.activeTexture(gl.TEXTURE0);
    gl.bindTexture(gl.TEXTURE_2D, render.backgroundTexture);
    gl.uniform1i(render.textureSamplerLocation, 0);

    gl.bindBuffer(gl.ARRAY_BUFFER, render.texturePositionBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(positions), gl.STREAM_DRAW);
    gl.enableVertexAttribArray(render.texturePositionLocation);
    gl.vertexAttribPointer(render.texturePositionLocation, 3, gl.FLOAT, false, 0, 0);

    gl.bindBuffer(gl.ARRAY_BUFFER, render.textureCoordBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(texCoords), gl.STREAM_DRAW);
    gl.enableVertexAttribArray(render.textureCoordLocation);
    gl.vertexAttribPointer(render.textureCoordLocation, 2, gl.FLOAT, false, 0, 0);

    gl.drawArrays(gl.TRIANGLES, 0, 6);
  }

  function drawGridOverlay(gl, metrics) {
    const world = State.world;
    const width = world.cols * metrics.tileWidth;
    const depth = world.rows * metrics.tileHeight;
    const lineVertices = [];

    for (let col = 0; col <= world.cols; col++) {
      const x = col * metrics.tileWidth;
      const start = logicalToRenderXZ(x, 0);
      const end = logicalToRenderXZ(x, depth);
      lineVertices.push(start.x, GRID_OVERLAY_Y, start.z, end.x, GRID_OVERLAY_Y, end.z);
    }

    for (let row = 0; row <= world.rows; row++) {
      const z = row * metrics.tileHeight;
      const start = logicalToRenderXZ(0, z);
      const end = logicalToRenderXZ(width, z);
      lineVertices.push(start.x, GRID_OVERLAY_Y, start.z, end.x, GRID_OVERLAY_Y, end.z);
    }

    drawLines(gl, lineVertices, [0.12, 0.17, 0.21, 0.55]);
  }

  function renderWorld(force) {
    const dom = State.dom;
    const world = State.world;
    const render = State.render;
    const gl = dom.gl;
    const metrics = getGridMetrics();
    if (!gl || (!render.colorProgram && !render.textureProgram) || !world.terrain.length) {
      clearTerrainShapeOverlay();
      return;
    }
    if (!force && !render.needsWorldRedraw) {
      drawTerrainShape2p5dOverlay();
      return;
    }

    gl.viewport(0, 0, dom.canvas.width, dom.canvas.height);
    gl.clearColor(render.clearColor[0], render.clearColor[1], render.clearColor[2], render.clearColor[3]);
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);

    drawBackgroundQuad(gl, metrics);
    if (State.camera.showGrid) drawGridOverlay(gl, metrics);

    if (world.hover) drawHoverMarker(gl, world.hover.row, world.hover.col, metrics.tileWidth, metrics.tileHeight);
    if (world.selected) drawSelectionMarker(gl, world.selected.row, world.selected.col, metrics.tileWidth, metrics.tileHeight);
    if (world.previewPath && world.previewPath.length > 1) drawPreviewRoute(gl, world.previewPath, metrics);

    if (world.player) {
      const playerPos = getPlayerWorldPosition();
      drawPlayer(gl, playerPos, metrics.tileWidth, metrics.tileHeight);
    }

    render.needsWorldRedraw = false;
    drawTerrainShape2p5dOverlay();
  }

  function drawTile(ctx, x, y, tileWidth, tileHeight, color) {
    ctx.fillStyle = color;
    ctx.fillRect(x - tileWidth / 2, y - tileHeight / 2, tileWidth, tileHeight);
  }

  window.Game.Renderer = {
    resizeCanvas,
    centerCamera,
    centerCameraOnTile,
    gridToScreen,
    screenToGridFloat,
    pickTile,
    renderWorld,
    drawTile,
    terrainColor,
    getRenderLevel,
    markDirty,
    getHexMetrics: getGridMetrics,
    getGridMetrics,
    pointInHex: pointInRect,
    pointInDiamond: pointInRect,
    pointInRect,
    updateCameraFollow,
    calculateFitZoom,
    updateZoomLimits,
    fitCameraToWorld,
    convertRenderDeltaToCameraDelta,
    ensureTerrainTexturesLoaded,
    getTerrainTextureStatus: function () {
      return {
        status: State.render.textureLoadStatus,
        count: Object.keys(State.render.textureImages || {}).length
      };
    }
  };
})();