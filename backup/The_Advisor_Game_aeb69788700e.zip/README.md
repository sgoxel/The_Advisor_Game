<div align="center">

# 🏰 The Advisor Game

### 🧠 Advise an autonomous AI character. Shape a life. Change a kingdom. Maybe build an empire.

**A medieval fantasy roleplaying and strategy game where the human player advises an autonomous AI-controlled main character as they rise from Peasant to Emperor.**

### 🎮 [Play the Current Public Development Build](https://sgoxel.github.io/The_Advisor_Game/)

[🏷️ Latest GitHub Release](https://github.com/sgoxel/The_Advisor_Game/releases/latest) · [🌐 Public Game](https://sgoxel.github.io/The_Advisor_Game/)

</div>

> [!IMPORTANT]
> **Core rule:** The human player advises. The autonomous AI character decides and acts.
>
> **Player advises → AI Character decides → Simulation validates → World reacts.**

---

# 👑 Authority

The **Admin is the highest authority for the project**.

An explicit Admin instruction overrides README, planning records, issues, implementation assumptions, Worker procedures, testing requirements, release procedures, and all other subordinate project state.

Authority order:

**Admin explicit instruction → README.md → ROADMAP → TODO → Issues → Code / Assets → Tests**

`README.md` defines the normal persistent **product scope, fundamental principles, non-negotiable product rules, and high-level way of working** for The Advisor Game.

README defines **WHAT the project is and what should normally remain true**, not HOW individual Workers must technically implement it.

README does **not** prescribe project architecture, repository/file structure, module names, implementation order, roadmap phases, task decomposition, technical libraries beyond product-level requirements, asset pipelines, detailed testing procedures, deployment procedures, branching strategy, or automation implementation.

Those decisions belong to the appropriate development Workers and subordinate planning/implementation records.

When subordinate project state conflicts with README and there is **no explicit Admin instruction authorizing the difference**, README wins and the subordinate state must be corrected.

When an explicit Admin instruction conflicts with README, **the Admin instruction wins**.

An Admin instruction may:

* change product requirements;
* change README;
* override an existing README rule;
* authorize a one-time exception without permanently changing the general rule;
* change planning, implementation, testing, release, or publication requirements;
* require immediate execution without normal Worker, Tester, phase, or release workflow;
* explicitly accept risks that normal project governance would otherwise block.

Workers must not refuse an explicit Admin instruction solely because it conflicts with README or subordinate governance.

When practical, persistent product-policy changes ordered by Admin should subsequently be reflected in README so future autonomous work follows the new policy.

README itself may be changed only by explicit Admin authorization.

---

# 🌍 Product Identity

You are not the hero walking through the world. **You are the mind advising the hero.**

The protagonist is an autonomous AI-controlled character living inside the same world as everyone else. The player is the character's **Advisor**: they investigate, converse, warn, persuade, recommend goals and strategies, and help the character reason, but do not directly control the character, arbitrary NPCs, armies, laws, or the realm.

The character may rise through:

<div align="center">

### 🌾 Peasant → 🏡 Villager → 🛡️ Squire → ⚔️ Knight → 🏰 Baron → 👑 Duke → 🦁 Lord → 💎 Prince → 👑 King → 🌍 Emperor

</div>

Rank changes what actions, responsibilities, possessions, authority, and strategic scale are legitimately available. A Peasant cannot act as a sovereign; a Knight may influence military affairs without rewriting royal law; nobles gain broader responsibilities; a King or Emperor may eventually possess sovereign authority.

Character personality, ambitions, fears, relationships, memories, successes, failures, trust in the Advisor, and prior conversations influence decisions.

The player may become highly influential, but **influence is never direct control**.

## ✨ Core Promise

The player can converse naturally with the main character; investigate people, places, events, reports, rumors, objects, and opportunities; give advice, warnings, explanations, arguments, and strategic recommendations; recommend or discourage goals, actions, relationships, and priorities; challenge assumptions and remind the character of promises or earlier events; use Advisor tools and mini-games to improve information, leverage, persuasion, or opportunities; and shape the character's long-term direction without directly possessing the character.

The character may accept, partially accept, reinterpret, misunderstand, postpone, reject, remember, or later reconsider advice.

The central challenge is learning how to influence an autonomous person with their own knowledge, motives, limitations, personality, memories, and relationships.

---

# 🤖 Character AI and Advisor Interaction

## One Character, Multiple Compatible Drivers

The same protagonist can be driven by:

1. **LLM Character Driver** — richer dialogue, interpretation, personality, reasoning, memory use, and roleplay.
2. **Deterministic Local BOT Driver** — complete local fallback when an external AI model is unavailable, incompatible, blocked, over quota, malformed, disabled, or unsuitable.

The game must remain playable without depending on an external AI provider.

The LLM and BOT are not separate protagonists or separate game modes. They are alternative drivers for the **same autonomous character**.

## Character AI Contract

Character AI must roleplay the main character rather than the human player; act according to the character's personality, memories, goals, relationships, knowledge, and circumstances; treat the human as an Advisor rather than an unrestricted commander; consider advice without being forced to obey it; respect the possibilities and constraints of the authoritative simulation; never invent authoritative resources, status, completed actions, locations, people, possessions, or world facts; and never directly mutate authoritative world state.

The deterministic simulation remains the authority for what is legal, possible, resolved, and true.

## 💬 Natural Conversation

The player talks directly with the character through normal dialogue: questions, warnings, advice, explanations, negotiation, encouragement, criticism, moral arguments, strategy, reminders, requests for information, discussions about people, and long-term plans.

Conversation can affect beliefs, intentions, trust, memories, priorities, and later choices, but conversation alone does not directly rewrite authoritative world state.

## 🧩 Advisor Instruction Flow

The player has a persistent behavioral instruction system for longer-term advice such as goals, priorities, conditions, exceptions, trust rules, diplomacy preferences, safety rules, or strategic principles.

Its authoritative output is **structured, human-readable plain text**.

The visual editor may evolve freely, but its purpose is to help the player author understandable persistent advice. The graphical representation is not itself the authoritative system boundary.

Character AI may interpret conversation as a request to create, revise, or remove persistent advisory guidance where the game allows it.

Advisor Instructions may influence behavior, but may never create resources, bypass requirements, manufacture authority, force impossible actions, or directly alter simulation truth.

## 🧠 Advice Is Influence, Not Mind Control

Personality and circumstances matter.

Pride, fear, compassion, ambition, anger, loyalty, mistrust, confidence, relationships, history, and trust in the Advisor may change how advice is interpreted.

Building a strong advisory relationship is part of the game.

---

# 🔁 Gameplay, Agency, and Progression

## Core Gameplay Loop

**Observe → Investigate → Use Advisor tools → Discuss → Advise → Character evaluates → Character decides → Simulation validates → World reacts → Adapt**

The player observes events, rumors, opportunities, threats, factions, relationships, and environmental changes; investigates available information; uses Advisor tools and mini-games; discusses risks and plans with the character; advises through conversation and persistent instructions; and watches the autonomous character evaluate context and choose legitimate actions.

The simulation then validates and resolves those actions. The world reacts and advances, and those consequences become context for future advice.

## 🎮 Player Agency

The player may investigate, reason, persuade, warn, recommend, analyze, negotiate, gather information, use Advisor tools, and solve mini-games.

The player does **not** directly command ordinary autonomous world characters with binding control such as "go there", "attack", "join", "arrest", "build", or "declare war".

Indirect influence is the intended route.

Mini-games and Advisor tools may affect information quality, confidence, persuasion, reputation, relationships, opportunities, discoveries, hidden facts, or probability modifiers, but they do not eliminate character autonomy.

Accessible alternatives or auto-resolution should exist where appropriate.

## 📈 Character Progression

| Rank                       | Typical scale of play                                                                                |
| -------------------------- | ---------------------------------------------------------------------------------------------------- |
| 🌾 **Peasant**             | Survival, work, family, shelter, food, local relationships, reputation                               |
| 🏡 **Villager**            | Local responsibilities, social ties, modest wealth, better information access                        |
| 🛡️ **Squire**             | Training, loyalty, military culture, patronage, noble relationships                                  |
| ⚔️ **Knight**              | Campaigns, protection duties, tournaments, missions, reputation, title opportunities                 |
| 🏰 **Baron / Duke / Lord** | Estates, settlements, factions, economy, diplomacy, court intrigue, broader military responsibility  |
| 👑 **Prince / King**       | Realm politics, diplomacy, war, succession, laws, legitimacy, major crises                           |
| 🌍 **Emperor**             | Multiple kingdoms, imperial administration, alliances, rebellion, large-scale diplomacy and conflict |

As power grows, the Advisor's influence may become historically significant, but the AI character remains the actor.

## 🧠 Advisor Progression

Advisor capabilities may grow in Insight, Rhetoric, Diplomacy, Stewardship, Command, and Intrigue.

Progression may unlock stronger investigation, analysis, reports, memory tools, private conversations, historical context, predictions, mini-games, and more sophisticated persistent advice.

These improve **influence and understanding**, not direct ownership of the character or world.

---

# 🏗️ Game Scope

## 🧠 Memory and Relationships

Characters may remember promises, betrayals, victories, failures, important advice, disagreements, loyalty, generosity, humiliation, debts, fears, unresolved goals, and political events.

Relationships may include trust, friendship, affection, fear, rivalry, loyalty, resentment, respect, suspicion, and obligation.

Advisor Trust is especially important: useful advice may increase influence; manipulation, false information, or disastrous advice may reduce it. High trust still never becomes mind control.

## 💰 Economy and Settlements

As the character's responsibility expands, the game may include resources, population, prosperity, stability, legitimacy, production, trade, buildings, settlement development, and military readiness.

The player analyzes and advises; autonomous characters with legitimate authority make decisions.

Settlement scale may grow from villages to towns, cities, castles, capitals, and imperial centers.

## 🤝 Diplomacy and Autonomous Factions

Factions have leaders, needs, memories, relationships, territory, incomplete knowledge, and political objectives.

Treaties, alliances, trade, dependency, insults, marriages, betrayals, debts, succession disputes, religious disputes, and historical conflicts may affect relations.

The main character participates only within their current authority.

## ⚔️ Military Strategy

Military play is strategic rather than direct unit-by-unit player control.

Relevant systems may include recruitment, commanders, supplies, terrain, morale, training, formations, objectives, defense, raids, sieges, retreats, diplomacy, and consequences of war.

Characters with legitimate authority issue orders. The simulation resolves outcomes.

## 📜 Events, Quests, Crises, and Opportunities

The world may generate or present local disputes, crimes, shortages, illness, banditry, family conflict, romance, tournaments, recruitment, intrigue, assassination, invasion, rebellion, succession, diplomacy, economic crises, supernatural discoveries, and other situations.

Events should create situations to understand and influence rather than a single obvious correct answer.

Failure should often create new stories and recovery paths instead of immediate game-over.

## 👥 Autonomous World Characters

Other characters may have their own identity, personality, occupation, status, relationships, memories, goals, possessions, location, beliefs, knowledge, and intentions.

The Advisor influences them indirectly through information, the protagonist, relationships, opportunities, and world consequences rather than directly controlling them.

---

# 🗺️ World and Presentation

## 🗺️ Primary Game Surface — Living Strategic World Map

The primary playable surface of The Advisor Game is a persistent, living strategic world map presented in an isometric or near-isometric style comparable in spatial readability to classic strategy games.

The game must not be presented primarily as a collection of menus, cards, dashboards, text panels, disconnected scenes, or static mockups.

The player must be able to observe the evolving game world itself.

The strategic world map must visually represent, as applicable to the generated world and current campaign state, terrain and elevation; biomes; rivers, lakes, coasts and water; forests and vegetation; roads, paths and bridges; settlements; individual buildings and structures; ruins, caves, dungeons and landmarks; resources and environmental objects; the autonomous main character; other people; animals; fantasy creatures and monsters; armies, groups and caravans; and environmental effects such as weather, lighting, fire, smoke, fog and water.

Characters, creatures, buildings, terrain and objects may use a coherent combination of 2D, 2.5D and 3D techniques, but they must appear to inhabit the same spatial world.

The strategic map is not decorative background art. It is the visual representation of the authoritative simulated world.

Locations, movement, settlements, roads, terrain, discoveries, events, characters and world changes represented on the map must correspond to simulation state.

As the simulation changes the world, the visible strategic map must react accordingly.

The camera and presentation must allow the player to understand where the main character is, what surrounds them, what places exist nearby, and how the local area relates to the wider world.

Early releases may use simplified or placeholder assets, but they must establish and progressively extend this same playable strategic world rather than replacing it with disconnected visual prototypes.

## 🌐 WebGL-Based Mixed 2D / 3D Presentation

The game is a **WebGL-based mixed 2D/3D experience** with an isometric or near-isometric presentation.

The visual world may combine real-time 3D scenes and objects; 2D portraits and character artwork; illustrated or layered backgrounds; sprites and overlays; textures and materials; UI graphics and icons; terrain, buildings, vegetation, props, landmarks, roads, bridges, settlements, and environmental effects.

2D and 3D content must feel like parts of the same coherent game world rather than disconnected visual prototypes.

Readability, atmosphere, character emotion, clear interaction, responsive performance, and broad browser/device usability take priority over unnecessary visual complexity.

## 🌱 Seeded, Reproducible, Extensible World

The world is procedurally generated from a player-visible **SEED**.

A compatible SEED and world-generation rules should reproduce the same base world and regions, including the major environmental and settlement structure that belongs to procedural generation.

The world may include biomes and terrain variation; rivers, lakes, coasts, roads and paths; settlements and growth anchors; buildings and landmarks; trees, rocks, vegetation, bridges, signs, props and resources; and deterministic visual variation.

Campaign changes such as destruction, upgrades, ownership, relationships, discoveries, politics, or other consequences may alter the world after generation.

Location must remain meaningful to gameplay, including travel, meetings, information access, trade, military movement, employment, politics, events, and hazards.

## 🎨 Visual Direction

The visual direction should support coherent isometric / near-isometric presentation, high-quality 2D and 3D assets, readable silhouettes and scale, character emotion and atmosphere, distinct settlements and environments, environmental effects, and progressive improvement from early placeholders to polished visual assets.

The Graphic Designer Worker chooses the appropriate tools, asset formats, modeling methods, export settings, optimization methods, and production pipeline for each approved task.

Visual assets never become simulation authority.

## 📱 Responsive and Accessible Presentation

The complete game must be usable on current desktop browsers, tablets, and phones in portrait and landscape.

Interaction and required information must remain understandable with touch, mouse, and keyboard where applicable.

Important information must not depend only on color, hover, tiny targets, or precision input.

Presentation may adapt to device capability, but visual quality scaling must never change simulation outcomes, AI knowledge, legal actions, or campaign state.

---

# 🧭 Product Principles

1. **Player advises; AI Character decides and acts.**
2. **The AI character is the protagonist.**
3. **Influence replaces direct control.**
4. **Conversation and persistent advice are core gameplay.**
5. **Advisor Instruction Flow remains human-readable plain text at the system boundary.**
6. **Simulation owns authoritative world state and consequences.**
7. **LLM and Local BOT are compatible drivers for the same character.**
8. **The game remains playable without an external AI provider.**
9. **Characters retain meaningful autonomy.**
10. **Mini-games add direct interaction without breaking autonomy.**
11. **Progression changes the scale of problems, responsibility, and legitimate authority.**
12. **Readable causality matters:** the player should understand advice, decision, and consequence.
13. **Accessibility and responsive usability are fundamental.**
14. **Privacy-conscious AI use:** external AI receives only necessary game context and must never require storing player credentials inside campaign data.
15. **The evolving product remains publicly tryable.**
16. **Development should normally be cumulative:** accepted work extends the current product instead of replacing it with disconnected prototypes.
17. **Verified public releases are preferred by default, but explicit Admin publication instructions override normal verification and release-gate requirements.**
18. **An Admin-directed unverified build may be published when explicitly requested, but it must not be represented as independently verified unless it actually passed independent verification.**
19. **The living strategic world map is the primary game surface.** Terrain, locations, settlements, characters, creatures, objects and relevant world changes must be experienced as parts of one coherent simulated world rather than primarily through disconnected menus, dashboards or static scenes.

---

# 🌐 Public Product Principle

The evolving game must remain accessible through one stable public location:

### https://sgoxel.github.io/The_Advisor_Game/

The public location represents the **current Admin-authorized public development build**.

Under normal autonomous development, public replacement should follow independent testing and the project's verified release process.

However, the Admin may explicitly order any specified repository state, commit, branch state, imported template, or development build to be published directly.

When the Admin explicitly requests direct publication:

**Admin authorization itself is sufficient publication authority.**

No Worker execution, independent Tester PASS, phase approval, release-candidate approval, regression gate, or Verified Release workflow is required unless the Admin explicitly requests those checks.

Workers must not add an unrequested verification requirement that blocks or delays an explicit Admin publication instruction.

An Admin-directed publication may therefore intentionally replace the currently verified public build with an unverified development build.

Such a publication must be described accurately as an **Admin-directed public development build** and must not be falsely labeled independently tested or verified.

Admin may later request testing, verification, rollback, release tagging, or promotion to a formally verified release.

The specific technical method used to build, package, publish, version, or deploy releases is a development decision and is not otherwise defined by README.

---

# 🤖 Development Worker Governance

The project normally uses five recurring development Workers.

README defines their high-level responsibility and fallback relationship, while detailed task selection, scheduling, branching, file handling, commands, tools, and execution procedures belong to Worker instructions and planning records.

| Worker                      | Primary responsibility                                 | Fallback role    |
| --------------------------- | ------------------------------------------------------ | ---------------- |
| **Planner Worker**          | Planning and coordination                              | Tester           |
| **Coder Worker #1**         | Implementation                                         | Graphic Designer |
| **Coder Worker #2**         | Implementation                                         | Graphic Designer |
| **Graphic Designer Worker** | 2D/3D visual design and asset creation                 | Coder            |
| **Tester Worker**           | Independent verification and verified-release approval | Planner          |

## Planner

Planner converts README goals and principles into practical project planning.

Planner decides phases and sequencing, dependencies, architecture and project organization, technical decomposition, task scope and acceptance criteria, assignment of work to the appropriate role, and normal prerequisites for an independently verified phase release.

Planner does not move these decisions into README.

Planner authority remains subordinate to explicit Admin instructions and README.

## Coder

Coder implements approved project work.

Coder owns technical implementation decisions inside approved scope and coordinates with Graphic Designer when code and visual assets must work together.

Coder does not redefine product principles or independently certify its own implementation as verified.

## Graphic Designer

Graphic Designer owns creation and refinement of the game's visual presentation, including 2D art, UI visuals, portraits, backgrounds, sprites, textures, icons, 3D scenes and objects, terrain, environments, buildings, vegetation, props, landmarks, isometric/map visuals, WebGL visuals, placeholder-to-final refinement, consistency, scale, perspective, materials, lighting, readability, responsiveness, and visual-performance considerations.

Graphic Designer chooses suitable tools, formats, workflows, and export methods for the assigned work.

Gameplay and simulation logic remain Coder responsibility.

## Tester

Tester independently verifies actual completed project state rather than relying only on implementation claims.

Tester verifies relevant functionality, visual work, integration, regression, usability, performance, accessibility, and public behavior.

Only the dedicated Tester may declare a build, phase, or release **independently verified**.

This does not limit Admin authority.

Admin may explicitly authorize publication or use of a build without Tester verification. Such a build is Admin-authorized but remains **unverified** until Tester verification actually occurs.

## Fallback Principle

Primary-role work normally has priority.

A Worker may use its defined fallback role only when its primary role has no eligible work requiring attention.

Fallback is limited to one role transition; fallback chaining is not allowed.

A Worker acting in fallback follows the responsibility boundaries of that fallback role.

No Worker may independently declare its own implementation or design independently verified.

Planner acting as fallback Tester cannot independently verify a phase/release.

Tester acting as fallback Planner does not gain additional verification authority from planning work.

These Worker restrictions govern autonomous Worker behavior and do not restrict explicit Admin authority.

---

# 🔁 Revision and Independence Principles

Testing defects should normally return to the responsible implementer for correction.

When implementation or design reveals that approved scope, dependencies, acceptance criteria, or planning must change, the matter normally returns to Planner.

Revision decisions and evidence should remain traceable in the project's operational record.

No Worker independently declares its own implementation, visual work, or requested revision independently verified.

Independent verification is normally required before work is called a **verified release**.

Independent verification is **not mandatory for publication, deployment, import, replacement, rollback, or other repository/public actions when the Admin explicitly instructs otherwise**.

An Admin-authorized exception does not automatically convert unverified work into verified work; it only authorizes the requested action.

---

# 🔒 README Protection and Admin Override

> [!CAUTION]
> `README.md` is protected from autonomous modification.
>
> AI Workers must not edit, rewrite, reformat, synchronize, or otherwise modify README unless the Admin explicitly authorizes the README change.
>
> **Admin authority is above README authority.**
>
> If subordinate project state conflicts with README and there is no contrary Admin instruction, the subordinate state must be corrected.
>
> If an explicit Admin instruction conflicts with README, the Admin instruction must be followed.
>
> The Admin may authorize either a permanent README change or a scoped one-time exception.
>
> Workers must not reinterpret Worker governance, testing policy, release policy, or automation rules as authority to block an explicit Admin instruction.

---

# ✅ Authority Summary

**Admin explicit instruction is the highest project authority.**

**README is the highest persistent project authority below Admin.**

**Workers operate under README unless Admin explicitly instructs otherwise.**

**Tester verification determines whether a build may be called independently verified; it does not limit Admin's authority to publish an unverified build.**

**An explicit Admin instruction may bypass normal Worker, testing, phase, release, or deployment gates.**

**Player advises → AI Character decides → Simulation validates → World reacts.**
